/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF THE 
** WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN THIS 
** FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE INSTRUCTOR 
** OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE TENURES OF THE 
** OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.      
*/
#include <stdio.h>
#include <stdlib.h>
#include "lab3.h"
/* Author: Zhiren Xu */


int main(){
	int num_of_book;
	int iter;
	int iter0;
	int iter1;
	int option;
	int num_of_fav_book;
	int num;
	int fav_book_sn;
	char in;
	int *fav_book_number;
	char *in_array;
	char *file_name;
	char **book_title_array;
	FILE *output_file;	

	printf("How many library book titles do you plan to enter? ");
	scanf("%d", &num_of_book);
	printf("%s%d%s", "Enter the ", num_of_book, " book titles one to a line: ");
	iter0 = 0;
	/* allocate memory for input array, book titles and get input */
	book_title_array = calloc(num_of_book, sizeof(char*));
	/* get rid of the first '\n' input */
	getchar();
	while(iter0 < num_of_book){
	    in_array = calloc(60, sizeof(char));
		*(book_title_array + iter0) = alloc_title_array(in_array, iter, in);
		iter0++;
	}
	printf("\n");

	/* print all book titles with number */
	printf("%s\n", "You've entered: ");	
	for(iter1 = 1; iter1 <= iter0; iter1++){
		printf("%d%s%s", iter1, ". ", *(book_title_array + (iter1-1)));
	}
	printf("\n");
	
	/* ask user to pick how many books on favorite list */
	printf("%s%d%s", "Of those ", num_of_book, " books, how many do you plan to put on your favorites list? ");
	scanf("%d", &num_of_fav_book);
	getchar();
	
	/* ask user to get title number of their favorite book and build double pointer for title array */
	fav_book_number = calloc(num_of_fav_book, sizeof(int));
	if(fav_book_number != NULL && num_of_fav_book != 0){
		printf("Enter the number next to each book title you want on your favorites list: ");
		iter1 = 0;
		while(iter1 < num_of_fav_book){
		    fav_book_sn = getchar();
		    if(fav_book_sn != 32){
		        *(fav_book_number + iter1) = (fav_book_sn - 1);
		        iter1++;
		    }
		}
		printf("\n");
		
	    /* print out the favorite list */
	    printf("The books on your favorite list are: \n");
	    populate_fav_book_list(num, num_of_fav_book, fav_book_number, book_title_array, iter1);
	    printf("\n");
	    getchar();
	
	    /* get file name and save everything to ASCII file if user approve */
	    printf("Do you want to save them (1=yes 2=no): ");
	    option = getchar();
	    if(option == '1'){
		printf("What file name do you want to use? ");
		getchar();
		file_name = calloc(256, sizeof(char));
		in = (char)getchar();
		iter1 = 0;
		while(in != '\n'){
		    *(file_name + iter1) = in;
		    in = (char)getchar();
		    iter1++;
		}
		save_fav_book_list_to_file(output_file, file_name, fav_book_number, book_title_array, num_of_book, num_of_fav_book, iter);
		
		printf("Your booklist and favorites have been saved to the file ");
    		iter0 = 0;
		while(iter1 > 0){
		    printf("%c", *(file_name + iter0));
		    iter0++;
		    iter1--;
		}
		printf(".\n");
	    }else{
		free_pointers(fav_book_number, in_array, book_title_array);
		}
	}

	/* free all pointers */
	free_all_pointers(fav_book_number, in_array, file_name, book_title_array);
}

/*
** Allocate mem address for char array. Length is 61 bytes.
** @param input_array
**      pointer that storage every char of book title
** @param i
**      iterator
** @param input
**      character of user input
** @return A 60 bytes char array pointer
*/
char *alloc_title_array(char *input_array, int i, char input){
	if(input_array != NULL){
		for(i = 0; i < 60 && input != '\n'; i++){
	        input = (char)getchar();
			*(input_array + i) = input;
		}
	}
	else{
		printf("memory allocate fail!");
	}
	return input_array;
}

/* 
** Print S/N and populates favorite book title.
** In C, int 1 = 49, 1 != '1'. To solve this problem, we need to decrease ASCII valuee of 0. e.g. int 1 -'0' = 49-48 = 1.
** @param number
**      decide which value shouldd we  pick from title_ptr
** @param fav_book_quantity
**      the quantity of favorite book
** @param fav_book_num
**      pointer which contain the S/N of user picked book
** @param title_ptr
**      double pointer where we get book title string
** @param i
**      iterator
*/ 
void populate_fav_book_list(int number, int fav_book_quantity, int *fav_book_num, char **title_ptr, int i){
    for(i = 0; i < fav_book_quantity; i++){
	        number = *(fav_book_num + i) - '0';
		    printf("%d%s%s", (i + 1), ". ", *(title_ptr + number));
	}
}

/*
** Create an ASCII file with user-input file name and write book list, favorite books in it.
** @param file_ptr
**	pointer create output file
** @param file_name_ptr
**	pointer of output file name array
** @param fav_book
**  S/N of favorite book
** @param title_ptr
**	double pointer of book title
** @param total_book_quantity
**	total number of book user enterd
** @param chosen_book_quantity
**	Total quantity of books user has chosen
** @param i
**	iterator
*/
void save_fav_book_list_to_file(FILE *file_ptr, char *file_name_ptr, int *fav_book, char **title_ptr, int total_book_quantity, int chosen_book_quantity, int i){
	file_ptr = fopen(file_name_ptr, "w");
	/* if file fail to open */
	if(file_ptr == NULL){
		perror("fopen");
		exit(EXIT_FAILURE);
	}
	fprintf(file_ptr, "Books I've Read: \n");
	for(i = 0; i < total_book_quantity; i++){
		fprintf(file_ptr, "%s", *(title_ptr + i));
	}
	fprintf(file_ptr, "\n");
	fprintf(file_ptr, "\n");
	fprintf(file_ptr, "My Favorites are: \n");
	for(i = 0; i < chosen_book_quantity; i++){
		fprintf(file_ptr, "%s",  *(title_ptr + (*(fav_book + i) - '0')));
	}
	/* close the file */
	if(fclose(file_ptr) != 0){
		perror("fclose");
		exit(EXIT_FAILURE);
	}
}

/*
** Frepointers.
** @param fav_book_number
**	pointer of favorite book title number
** @param input_array
**  pointer that storage every char of book title
** @param title_ptr
**	double pointer	of book title
*/
void free_pointers(int *fav_book_num, char *input_array, char **title_ptr){
	free(fav_book_num);
	fav_book_num = NULL;
	free(input_array);
	input_array = NULL;
	free(title_ptr);
	title_ptr = NULL;
}

/*
** Free all pointers.
** @param fav_book_number
**	pointer of favorite book title number
** @param input_array
**  pointer that storage every char of book title
** @param file_name_ptr
**	pointer of output file name array
** @param title_ptr
**	double pointer	of book title
*/
void free_all_pointers(int *fav_book_num, char *input_array, char *file_name_ptr, char **title_ptr){
	free(fav_book_num);
	fav_book_num = NULL;
	free(input_array);
	input_array = NULL;
	free(file_name_ptr);
	file_name_ptr = NULL;
	free(title_ptr);
	title_ptr = NULL;
}
