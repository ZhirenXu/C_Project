#include <stdlib.h>
#include "linkedlist.h"

typedef struct Node
{
	void *data;
	struct Node *next;
};

int insert(void *p2head, void *data, ComparisonFunction goesInFrontOf, FILE *diagnostics)
{
	struct Node p2p2change = p2head;
	struct Node newNode = data;
	
	fprintf(diagnostics, "inserting %d (lives at 0x%x)\n", newNode.data, newNode);
	while(*p2p2change != NULL && goesInFrontOf((**p2p2change).data, newNode)))
	{
		fprintf(diagnostics, "Going past %d\n", (**p2p2change).data);
		p2p2change = &((**p2p2change).next);
	}
	newNode.next = *p2p2change;
	*p2p2change = newNode;
	fprintf(diagnostics, "Setting changed to 0x%x, next to 0x%x\n", *p2p2change, newNode.next);
}

void deleteSome(void *p2head, CriteriaFunction mustGo, ActionFunction disposal, FILE *diagnostics)
{	
	void *holder;
	struct Node p2p2change;
	
	p2p2change = p2head;
	holder = &((**holder));
	
	while (p2p2change != NULL)
	{
		/* if headPtr point to correct Node */
		if (mustGo(holder))
		{
			fprintf(diagnostics, "deletinging %d (lives at 0x%x)\n", *holder->data, holder);
			/* delete that node */
			disposal(holder);
			break;
		}
		/* set headPtr to the next node */
		p2p2change = &((**p2p2change).next);
		/* set the holder to point to another node */
		holder = &((**p2p2change));
	}
}

void iterate(void *head, ActionFunction doThis)
{
	struct Node *traversePtr = head;
	
	while(traversePtr != NULL)
	{
		doThis(traversePtr);
		traversePtr = traversePtr->next;
	}
}

void sort(void *head, ComparisonFunction goesInFrontOf)
{
	struct Node *previousPtr = head;
	struct Node *traversePtr = previousPtr->next;
	int finish = 0;
	int result;
	void *previousData;
	void *traverseData;
	
	while(finish)
	{
		result = goesInFrontOf(previousPtr, traversePtr);
		if(result > 0)
		{
			traverseData = traversePtr->data;
			previousData = previousPtr->data;
			*(traversePtr->data) = previousData;
			*(previousPtr->Data) = traverseData;
			previousPtr = previousPtr->next;
			traversePtr = traversePtr->next;
		}
		finish = finish + result;
	}
			
}
