
/* Neil Kirby SP 2020 lab 3
 * functtions.c
 * all of the functions passed to the list machine
 */
#include <stdio.h>
#include <math.h>

#include "constants.h"

#include "structs.h"
#include "alt_plane.h"


/**************************************** helper functions not passed
 * to list machine 
 */
/* No function change except fprintf target */

short flightLevel(double fpalt)
{
	int alt;
	int thou;
	int add = 0, mod;
	short fl;

	alt = lround(fpalt);
	thou = alt / 1000;
	mod = alt % 1000;
	if(mod >= 250) add +=5;
	if(mod >= 750) add +=5;
	fl = thou * 10 + add;
	return fl;
}

double delta_XY(short heading, short knots, int seconds, double trig)
{
	/* pile of unit conversions coming at you */
	/* let us do feet per second 
	double feet = KNOTS_TO_FPS * knots * seconds * trig;
	*/
	return(KNOTS_TO_FPS * knots * seconds * trig);

}

double nextY(double y, short heading, short knots, int seconds)
{
	return y + delta_XY(heading, knots, seconds, cos(M_PI / 180 *heading));
}

double nextX(double x, short heading, short knots, int seconds)
{
	return x + delta_XY(heading, knots, seconds, sin(M_PI / 180 *heading));
}

/* convert X coord to graphics column - these stay int*/
int gx(int x)
{
	/* output range is al_min_X to al_max_X going right */
	/* input range is 0 to less than 380 miles * 5280  going east*/
	int column, ncols;
	ncols = 1 + al_max_X() - al_min_X();
	column = al_min_X() + ncols * x / FEET_X;
	return column;
}


/* convert y to graphics row number - these stay int*/
int gy(int y)
{
	/* input range is 0 to less than 280 miles * 5280, going north */
	/* output has quadrant shift; the south generates large row
	 * and the north generates small row numbers */

	int row, nrows;
	nrows = 1 + al_max_Y() - al_min_Y();
	row = al_max_Y() - nrows * y / FEET_Y;
	return row;

}

/*************************************** end of helpers **********/


/* comparison functions */
int higher( void *high, void *low)
{
	struct plane *h, *l;
	h = high;
	l = low;
	return(h->altitude >= l->altitude);
}

int westmost(void *west, void *east)
{
	struct plane *w, *e;
	w = west;
	e = east;
	return(w->x <= e->x);
}


/* criteria functions */
int always(void *data)
{
	return 1;
}

int outside_colorado(void *data)
{
	struct plane *jet;

	jet = data;
	return(
	    jet->x < 0 ||
	    jet->y < 0 ||
	    jet->x >= FEET_X ||
	    jet->y >= FEET_Y
	);
}


/* action functions */
void dispose_plane(void *data)
{
	struct plane *p;
	p = data;
    	fprintf(p->sim->diagnostics,"DIAGNOSTIC: %s leaves the simulation.\n", p->callsign);
	recycle_plane(p, p->sim->diagnostics);
}

void print_plane(void *data)
{
	struct plane *jet;

	jet = data;
	fprintf(jet->sim->out, "%14s (%7.0f, %7.0f) (%3d, %3d) %5.0fft FL%3d %4dK H%3d\n", jet->callsign, jet->x, jet->y, gx(jet->x), gy(jet->y), jet->altitude, 
    	flightLevel(jet->altitude), jet->knots, jet->heading);

}

void draw_plane(void *data)
{
	struct plane *jet;

	jet = data;
	al_plane(gx(jet->x), gy(jet->y), jet->callsign, 
	    flightLevel(jet->altitude), jet->knots, jet->heading);
}


void move_plane(void *data)
{
	struct plane *jet;

	jet = data;
	jet->x = nextX(jet->x, jet->heading, jet->knots, DELTA_T);
	jet->y = nextY(jet->y, jet->heading, jet->knots, DELTA_T);
	/* ROC is feet per minute, we use seconds to update */
	jet->altitude +=  jet->ROC / 60.0 * DELTA_T ; 
}



