#include "linkedlist.h"
#include "plane.h"

void p_iniJet()
{
	typedef int (* ComparisonFunction)(void *data1, void *data2);
	typedef void (* ActionFunction)( void *data);
	void *structHeader;
	void *p2header = structHeader;
	struct plane *jet0 = allocate_plane(stdout);
	struct plane *jet1 = allocate_plane(stdout);
	
	structHeader = (void)jet0;
	insert(p2header, void(jet1), ComparisonFunction goesInFrontOf(structHeader, jet1), stdout);
}
