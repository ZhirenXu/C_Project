/* Author: Zhiren Xu */
#include "libatc.h"
#include <stdio.h>
#include "structs.h"
int param_count(struct simulation *sim)
{
	if (sim->argc == 4)
	{
		fprintf(stderr, "%s\n", "DIAGNOSTIC: Startup: parameter count SUCCESS");
		return 1;
	}
	else
	{
		fprintf(stderr, "%s\n", "DIAGNOSTIC: Startup: parameter count FAIL");
	}
	return 0;
}

int open_dignostics(struct simulation *sim)
{
	char *fileName;
	
	fileName = sim->argv[3];
	sim->diagnostics = fopen(sim->argv[3], "w");
	if (sim->diagnostics != NULL)
	{
		fprintf(sim->diagnostics, "%s%s%s\n", "DIAGNOSTIC: Startup: Open ", fileName, " for diagnostics SUCCESS");
		return 1;
	}
	fprintf(stdout, "%s\n", "DIAGNOSTIC: Startup: Open file for diagnostics FAIL");
	return 0;
}

int open_text(struct simulation *sim)
{
	char *fileName;
	
	fileName = sim->argv[2];
	sim->out = fopen(sim->argv[2], "w");
	if (sim->out != NULL)
	{
		fprintf(sim->diagnostics, "%s%s%s\n", "DIAGNOSTIC: Startup: Open ", fileName, " for text output SUCCESS");
		return 1;
	}
	fprintf(sim->diagnostics, "%s\n", "DIAGNOSTIC: Startup: Open file for text output FAIL");
	return 0;
}

int open_input(struct simulation *sim)
{
	char *fileName;
	
	fileName = sim->argv[1];
	sim->in = fopen(sim->argv[1], "r");
	if (sim->in != NULL)
	{
		fprintf(sim->diagnostics, "%s%s%s\n", "DIAGNOSTIC: Startup: Open ", fileName, " for input SUCCESS");
		return 1;
	}
	fprintf(sim->diagnostics, "%s\n", "DIAGNOSTIC: Startup: Open file for input FAIL");
	return 0;
}

int up_graphics(struct simulation *sim)
{
	if (al_initialize() == 1)
	{
		fprintf(sim->diagnostics, "%s\n", "DIAGNOSTIC: Startup: al_init() SUCCESS");
		return 1;
	}
	else
	{
		fprintf(sim->diagnostics, "%s\n", "DIAGNOSTIC: Startup: al_init() FAIL");
		return 0;
	}
}

void do_nothing(struct simulation *sim)
{
	fprintf(stdout, "%s\n", "DIAGNOSTIC: Shutdown: do nothing called");
}

void close_diagnostics(struct simulation *sim)
{
	fclose(sim->diagnostics);
	sim->diagnostics = stderr;
	fprintf(sim->diagnostics, "%s\n", "DIAGNOSTIC: Shutdown: Close diagnostics file err");
}

void close_text(struct simulation *sim)
{
	fclose(sim->out);
	fprintf(sim->diagnostics, "%s\n", "DIAGNOSTIC: Shutdown: Close text output file text");
	sim->out = stdout;
}

void close_input(struct simulation *sim)
{
	fclose(sim->in);
	fprintf(sim->diagnostics, "%s\n", "DIAGNOSTIC: Shutdown: Close input file");
	sim->in = stdin;
}

void down_graphics(struct simulation *sim)
{
	al_teardown();
	fprintf(sim->diagnostics, "%s\n", "DIAGNOSTIC: Shutdown: calling al_teardown()");
}

void init_sequencer(struct sequence_machine *sm)
{
	/* the following 2 lists must be kept in lockstep */
	initializer init[] = {param_count, open_dignostics, open_text, open_input, up_graphics};
	shutdown_function final[] = {do_nothing, close_diagnostics, close_text, close_input, down_graphics};
	int i;
	
	sm->at = 0;
	sm->count = sizeof(init) / sizeof(init[0]);
	for(i=0; i< sm->count; i++)
	{
		sm->entries[i].startup =init[i];
		sm->entries[i].shutdown = final[i];
	}
}

void init_sim(struct simulation *sim, int argc, char *argv[])
{
	sim->list = NULL;
	sim->argc = argc;
	sim->argv[1] = argv[1];
	sim->argv[2] = argv[2];
	sim->argv[3] = argv[3];
	sim->in = stdin;
	sim->out = stdout;
	sim->diagnostics = stderr;
}

void master_startup(struct sequence_machine *sm, struct simulation *sim)
{
	int i;
	
	for (i = 0; i < (sm->count); i++)
	{
		if (sm->entries[i].startup(sim) != 1)
		{
			break;
		}
	}
	/* eliminate 1-off problem */
	sm->at = i - 1;
}

void master_shutdown(struct sequence_machine *sm, struct simulation *sim)
{
	while ((sm->at) >= 0)
	{
		sm->entries[sm->at].shutdown(sim);
		(sm->at) = (sm->at) - 1;
	}
}	
	
int main(int argc, char *argv[])
{
	struct simulation Colorado, *sim = &Colorado;
	struct sequence_machine SM, *sequencer = &SM;
	
	init_sim(sim, argc, argv);
	init_sequencer(sequencer);
	master_startup(sequencer, sim);
	master_shutdown(sequencer, sim);
	return 0;
}
	
