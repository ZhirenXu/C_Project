/* Author: Zhiren Xu */
#include "libatc.h"
#include <stdio.h>
#include "structs.h"
#include "sequencer.h"
/* count how many parameters from cmd args */
int param_count(struct simulation *sim)
{
	if (sim->argc == 4)
	{
		fprintf(stderr, "%s\n", "DIAGNOSTIC: Startup: parameter count SUCCESS");
		return 1;
	}
	else
	{
		fprintf(stderr, "%s\n", "DIAGNOSTIC: Startup: parameter count FAIL");
	}
	return 0;
}

/* attempt to open dignostics file */
int open_dignostics(struct simulation *sim)
{
	char *fileName;
	
	fileName = sim->argv[3];
	sim->diagnostics = fopen(sim->argv[3], "w");
	if (sim->diagnostics != NULL)
	{
		fprintf(sim->diagnostics, "%s%s%s\n", "DIAGNOSTIC: Startup: Open ", fileName, " for diagnostics SUCCESS");
		return 1;
	}
	fprintf(stdout, "%s\n", "DIAGNOSTIC: Startup: Open file for diagnostics FAIL");
	return 0;
}

/* attempt to open output file */
int open_text(struct simulation *sim)
{
	char *fileName;
	
	fileName = sim->argv[2];
	sim->out = fopen(sim->argv[2], "w");
	if (sim->out != NULL)
	{
		fprintf(sim->diagnostics, "%s%s%s\n", "DIAGNOSTIC: Startup: Open ", fileName, " for text output SUCCESS");
		return 1;
	}
	fprintf(sim->diagnostics, "%s\n", "DIAGNOSTIC: Startup: Open file for text output FAIL");
	return 0;
}

/* attempt to open input file */
int open_input(struct simulation *sim)
{
	char *fileName;
	
	fileName = sim->argv[1];
	sim->in = fopen(sim->argv[1], "r");
	if (sim->in != NULL)
	{
		fprintf(sim->diagnostics, "%s%s%s\n", "DIAGNOSTIC: Startup: Open ", fileName, " for input SUCCESS");
		return 1;
	}
	fprintf(sim->diagnostics, "%s\n", "DIAGNOSTIC: Startup: Open file for input FAIL");
	return 0;
}

/* attempt to start graphic output in terminal */
int up_graphics(struct simulation *sim)
{
	if (al_initialize() == 1)
	{
		fprintf(sim->diagnostics, "%s\n", "DIAGNOSTIC: Startup: al_init() SUCCESS");
		return 1;
	}
	else
	{
		fprintf(sim->diagnostics, "%s\n", "DIAGNOSTIC: Startup: al_init() FAIL");
		return 0;
	}
}

/* do nothing, just print out dignostic file */
void do_nothing(struct simulation *sim)
{
	fprintf(stdout, "%s\n", "DIAGNOSTIC: Shutdown: do nothing called");
}

/* attempt to close dignostic file */
void close_diagnostics(struct simulation *sim)
{
	fclose(sim->diagnostics);
	sim->diagnostics = stderr;
	fprintf(sim->diagnostics, "%s\n", "DIAGNOSTIC: Shutdown: Close diagnostics file err");
}

/* attempt to close output file */
void close_text(struct simulation *sim)
{
	fclose(sim->out);
	fprintf(sim->diagnostics, "%s\n", "DIAGNOSTIC: Shutdown: Close text output file text");
	sim->out = stdout;
}

/* attempt to close input file */
void close_input(struct simulation *sim)
{
	fclose(sim->in);
	fprintf(sim->diagnostics, "%s\n", "DIAGNOSTIC: Shutdown: Close input file");
	sim->in = stdin;
}

/* attempt to close graphic output */
void down_graphics(struct simulation *sim)
{
	al_teardown();
	fprintf(sim->diagnostics, "%s\n", "DIAGNOSTIC: Shutdown: calling al_teardown()");
}

/* list all funtions in func struct and assign them to sequencer func pointer */
void init_sequencer(struct sequence_machine *sm)
{
	/* the following 2 lists must be kept in lockstep */
	initializer init[] = {param_count, open_dignostics, open_text, open_input, up_graphics};
	shutdown_function final[] = {do_nothing, close_diagnostics, close_text, close_input, down_graphics};
	int i;
	
	sm->at = 0;
	sm->count = sizeof(init) / sizeof(init[0]);
	for(i=0; i< sm->count; i++)
	{
		sm->entries[i].startup =init[i];
		sm->entries[i].shutdown = final[i];
	}
}

/* initial and give value to sim struct members */
void init_sim(struct simulation *sim, int argc, char *argv[])
{
	sim->list = NULL;
	sim->argc = argc;
	sim->argv[1] = argv[1];
	sim->argv[2] = argv[2];
	sim->argv[3] = argv[3];
	sim->in = stdin;
	sim->out = stdout;
	sim->diagnostics = stderr;
}

/* a master function to start all function in initializer */
int master_startup(struct sequence_machine *sm, struct simulation *sim)
{
	int i;
	
	for (i = 0; i < (sm->count); i++)
	{
		if (sm->entries[i].startup(sim) != 1)
		{
			return 0;
		}
	}
	/* eliminate 1-off problem */
	sm->at = i - 1;
	return 1;
}

/* a master function to start all function in shutdown_function */
void master_shutdown(struct sequence_machine *sm, struct simulation *sim)
{
	while ((sm->at) >= 0)
	{
		sm->entries[sm->at].shutdown(sim);
		(sm->at) = (sm->at) - 1;
	}
}
	
