
/* Neil Kirby lab 3 SP 2020 */
/* modified by: Zhiren Xu */
struct simulation 
{
	void *list;
	int argc;
	char *argv[5];
	FILE *in;
	FILE *out;
	FILE *diagnostics;
	int et; /* in seconds */
};

typedef int (*initializer)(struct simulation *sim);
typedef void(*shutdown_function)(struct simulation *sim);

struct plane 
{
	double x, y, altitude;
	int ROC; /* feet per minute */
	int pilot;
	short heading, knots;
	char callsign[15];
	struct simulation *sim;
};

struct SeqStage
{
	initializer startup;
	shutdown_function shutdown;
};

struct sequence_machine
{
	int at;
	struct SeqStage entries[5];
	int count;
};

