#include <stdlib.h>
#include <stdio.h>

int main(int argc, char *argv[])
{
	FILE *out = fopen(argv[1], "w");
	if(out != NULL)
	{
		fprintf(stdout, "%s", "DIAGNOSTIC: Startup: Open file text for text output SUCCESS\n");
		return 1;
	}
	fprintf(stdout, "%s", "DIAGNOSTIC: Startup: Open file text for text output FAIL\n");
	return 0;
}
