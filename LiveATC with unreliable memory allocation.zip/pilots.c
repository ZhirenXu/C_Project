
/* Neil Kirby SP 2020 lab 3
 * all of the functions for pilots
 */

/* No comment because no function is touched except fprintf target */
#include <stdio.h>


#include "structs.h"

void snl(struct plane *jet)
{
	fprintf(jet->sim->diagnostics,"DIAGNOSTIC: %s is flying straight and level.\n", 
		jet->callsign);
	jet->ROC=0;
}

short newHeading(short old, int delta)
{
	old += delta;
	if (old < 0 ) old+= 360;
	if (old >= 360) old -= 360;
	return old;
}


void climbright(struct plane *jet)
{
	if (jet->altitude < 30500)
	{
    		fprintf(jet->sim->diagnostics,"DIAGNOSTIC: %s is turning right and ", jet->callsign);
	    	jet->heading = newHeading(jet->heading, 15);
	}
	else
	{
    		fprintf(jet->sim->diagnostics,"DIAGNOSTIC: %s is flying straight and ", jet->callsign);
	}

	if(jet->altitude < 33500)
	{
	    fprintf(jet->sim->diagnostics, "climbing.\n");
	    jet->ROC= 400;
	}
	else 
	{
	    fprintf(jet->sim->diagnostics, "leveled off.\n");
	    jet->ROC = 0;
	}
}

void descendleft(struct plane *jet)
{


	if (jet->altitude > 20500)
	{
    		fprintf(jet->sim->diagnostics,"DIAGNOSTIC: %s is turning left and ", jet->callsign);
	    	jet->heading = newHeading(jet->heading, -15);
	}
	else
	{
    		fprintf(jet->sim->diagnostics,"DIAGNOSTIC: %s is flying straight and ", jet->callsign);
	}

	if(jet->altitude > 19500)
	{
	    fprintf(jet->sim->diagnostics, "descending.\n");
	    jet->ROC= -400;
	}
	else 
	{
	    fprintf(jet->sim->diagnostics, "leveled off.\n");
	    jet->ROC = 0;
	}
}

void pilot_input(void *data)
{
	void (*fp[])(struct plane *jet) = {snl, descendleft, climbright};
	int mx = sizeof(fp)/sizeof(fp[0]) -1;
	struct plane *jet;

	jet = data;
	if( (jet->pilot >= 0) && (jet->pilot <= mx) )
	{
		fp[jet->pilot](jet);
	}
	else
	{
		fprintf(jet->sim->diagnostics,"ERROR: %s has bad pilot %d\n", jet->callsign, jet->pilot);
	    	jet->pilot = 0;
	}
}
