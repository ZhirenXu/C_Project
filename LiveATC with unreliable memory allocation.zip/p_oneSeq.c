/* Author: Zhiren Xu */
#include "libatc.h"
#include <stdio.h>
#include "structs.h"
int param_count(struct simulation *sim)
{
	if (sim->argc == 4)
	{
		fprintf(sim->diagnostics, "%s", "DIAGNOSTIC: Startup: parameter count SUCCESS");
		return 1;
	}
	else
	{
		fprintf(sim->diagnostics, "%s", "DIAGNOSTIC: Startup: parameter count FAIL");
	}
	return 0;
}

void do_nothing(struct simulation *sim)
{
	fprintf(sim->diagnostics, "%s", "DIAGNOSTIC: Shutdown:do nothing called");
}

void init_sequencer(struct sequence_machine *sm)
{
	/* the following 2 lists must be kept in lockstep */
	initializer init[] = {param_count};
	shutdown_function final[] = {do_nothing};
	int i;
	
	sm->at = 0;
	sm->count = sizeof(init) / sizeof(init[0]);
	for(i=0; i< sm->count; i++)
	{
		sm->entries[i].startup =init[i];
		sm->entries[i].shutdown = final[i];
	}
}

void init_sim(struct simulation *sim, int argc, char *argv[])
{
	sim->list = NULL;
	sim->argc = argc;
	sim->in = fopen(argv[1], "r");
	sim->out = fopen(argv[2], "w");
	sim->diagnostics = fopen(argv[3], "w");
}

void master_startup(struct sequence_machine *sm, struct simulation *sim)
{
	int i;
	
	for (i = 0; i < 1; i++)
	{
		if (sm->entries[i].startup(sim) != 1)
		{
			break;
		}
	}
}
int main(int argc, char *argv[])
{
	struct simulation Colorado, *sim = &Colorado;
	struct sequence_machine SM, *sequencer = &SM;
	
	init_sim(sim, argc, argv);
	init_sequencer(sequencer);
	master_startup(sequencer, sim);
	return 0;
}
	
