/* Neil Kirby Lab 3 SP2020 */
/* changed by: Zhiren Xu */
#include <stdio.h>
#include "libatc.h"
#include "constants.h"
/* order matters for the next two */
#include "structs.h"
#include "alt_plane.h"
#include "functions.h"

#define FALSE 0
#define GRAPHICS 1


/* with only one function, I just listed it instead of making a header file
 * for it. */
void pilot_input(void *data);

/* print elasped time during sim in dignostic file. */
void numeric_header(struct simulation *sim)
{

    	fprintf(sim->out, "\nElapsed time: %5d seconds.\n", sim->et);
	fprintf(sim->diagnostics, "\nElapsed time: %5d seconds.\n\n", sim->et);
	/* taken from format string for numbers with a leading space to 
	 * mathc the s after elapsed time */
	fprintf(sim->out, "%14s (%7s, %7s) (%3s, %3s) %5s   FL%3s %4s  %3s\n",
    "Callsign", "x", "y", "gx", "gy", "Alt", "", "Knots", "Deg");

}

/* Use libatc functions tp get graphic output */
void graphical_output(struct simulation *sim)
{
	if(GRAPHICS)
	{
	    sort(sim->list, higher);
	    al_clear();
	    al_clock(sim->et);

	    iterate(sim->list, draw_plane);
	    
	    al_refresh();
	    sleep(1);
	}
}

/* Write plane parameters into output file in sim struct */
void text_output(struct simulation *sim)
{
	sort(sim->list, westmost);
	numeric_header(sim);
	iterate(sim->list, print_plane);
	fprintf(sim->out, "\n");
}

/* fire up textOutput to output file and graphicOutput to screen */
void master_output(struct simulation *sim)
{
	text_output(sim);
	graphical_output(sim);
}

/* use linkedlink to control planes' behavior */
void fly_planes(struct simulation *sim)
{
	while(sim->list) /* null when no planes */
	{
	    master_output(sim);
	    /* update clock */
	    sim->et += DELTA_T;

	    /* pilot input*/
	    iterate(sim->list, pilot_input);

	    /* move planes */
	    iterate(sim->list, move_plane);
	    deleteSome(&sim->list, outside_colorado, dispose_plane); 

	    /* for testing - especially if move isn't working */
	    /* deleteSome(&sim->list, always, dispose_plane); */
	}
}

/* allocting plane and insert into sim struct */
void add_plane_to_sim(struct plane *fake, struct simulation *sim)
{
	struct plane *real;
	if( real = allocate_plane(sim->diagnostics))
	{
	    /* copy the data and toss on the list */
	    *real = *fake;
	    /* Add code to handle insert fail */
	    if (FALSE == insert(&sim->list, real, higher))
	    {
	    	recycle_plane(real, sim->diagnostics);
	    }
	}
	/* no else - allocate plane already complained */

}

/* read plane from input file in sim struct and add into sim */
void read_planes(struct simulation *sim)
{
	int conversions;
	struct plane flyer;

	flyer.sim = sim;
	while( (conversions = fscanf(sim->in, "%s %lf %lf %lf %hd %hd %d", 
		flyer.callsign, &flyer.x, &flyer.y, &flyer.altitude, 
		&flyer.knots, &flyer.heading, &flyer.pilot)) == 7)
	{
	    add_plane_to_sim(&flyer, sim);
	}
	fprintf(sim->diagnostics, "Failed to read: fscanf returned %d\n", conversions);

}

/* print terminal window size into dignostic file */
void print_sizes(struct simulation *sim)
{
	fprintf(sim->diagnostics,"Drawable area is (%d, %d) to (%d, %d)\n", al_min_X(), al_min_Y(), al_max_X(), al_max_Y());
}

/* the master function to run all simulation */
void attempt_sim(struct simulation *sim)
{
	print_sizes(sim);
	read_planes(sim);
	fly_planes(sim);
	recycle_plane(sim->list, sim->diagnostics);
}

int main(int argc, char *argv[])
{
	struct simulation Colorado, *sim = &Colorado;
	struct sequence_machine SM, *sequencer = &SM;
	
	init_sim(sim, argc, argv);
	init_sequencer(sequencer);
	/* declare of sequence machine */
	
	if(master_startup(sequencer, sim))
	{
	    /* attempt until failure*/
	    attempt_sim(sim);
	    
	}
	master_shutdown(sequencer, sim);
}

