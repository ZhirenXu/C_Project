
/* Neil Kirby SP 2020 */

# define M_PI           3.14159265358979323846  /* pi */
#define FEET_X (5280 * 380)
#define FEET_Y (5280 * 280)
#define KNOTS_TO_FPS 1.687809855643 
#define DELTA_T 60

