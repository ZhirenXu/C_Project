
/* Neil Kirby SP 2020 */


/* comparisons */
int higher( void *high, void *low);
int westmost( void *west, void *east);

/* criteria */
int always(void *data);
int outside_colorado(void *data);

/* actions */
void dispose_plane(void *data);

void print_plane(void *data);
void draw_plane(void *data);
void move_plane(void *data);


