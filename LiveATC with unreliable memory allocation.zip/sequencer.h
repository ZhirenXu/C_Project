/* Author: Zhiren Xu */

int param_count(struct simulation *sim);
int open_dignostics(struct simulation *sim);
int open_text(struct simulation *sim);
int open_input(struct simulation *sim);
int up_graphics(struct simulation *sim);
void do_nothing(struct simulation *sim);
void close_diagnostics(struct simulation *sim);
void close_text(struct simulation *sim);
void close_input(struct simulation *sim);
void down_graphics(struct simulation *sim);
void init_sequencer(struct sequence_machine *sm);
void init_sim(struct simulation *sim, int argc, char *argv[]);
int master_startup(struct sequence_machine *sm, struct simulation *sim);
void master_shutdown(struct sequence_machine *sm, struct simulation *sim);
