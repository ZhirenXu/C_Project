
/* Neil Kirby SP 2020 */


struct plane *allocate_plane(FILE *diagnostics);
void recycle_plane(struct plane *jet, FILE *diagnostics);

