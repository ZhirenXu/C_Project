
/* Neil Kirby lab3 SP 2020 */

#include <stdio.h>
#include <stdlib.h>
#include "alt_plane.h"

void recycle_plane(struct plane *jet, FILE *diagnostics)
{
	static int count=0;
	if(jet)
	{
	    free(jet);
	    count++;
    fprintf(diagnostics, "DIAGNOSTIC: recycle_plane: %d planes recycled.\n", count);
	}
	else
	{
    fprintf(diagnostics, "ERROR: recycle_plane: NULL pointer.\n" );
    	}
}

struct plane *allocate_plane(FILE *diagnostics)
{
	struct plane *jet;
	static int count=0;

	if( jet = calloc(1, sizeof(struct plane)))
	{
	    count++;
    fprintf(diagnostics, "DIAGNOSTIC: allocate_plane: %d planes allocated.\n", count);
	}
	else
	{
    fprintf(diagnostics, "allocate_plane failed to allocate memory.\n");
	}
	return jet;

}

