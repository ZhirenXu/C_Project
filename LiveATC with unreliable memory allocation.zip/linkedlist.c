#include <stdlib.h>
#include "linkedlist.h"

int insert(void *p2head, void *data, ComparisonFunction goesInFrontOf, FILE *diagnostics)
{
	
	Node *traversePtr = NULL;
	Node *priorNode = NULL;
	Node *newNode;
	
	if (data && p2head == NULL)
	{
		p2head = &data;
	}
	else if (data && *p2head != *data)
	{
		newNode->Node *traversePtr;
		(* ActionFunction)(data);
		newNode->next = traversePtr;
		pirorNode->next = newNode;
	}
	else
	{
		return FALSE;
	}
}

void deleteSome(void *p2head, CriteriaFunction mustGo, ActionFunction disposal, FILE *diagnostics)
{
	Node *traversePtr;
	struct Node *priorNode;
	
	traversePtr = &p2head;
	if (traversePtr == NULL)
	{
		fprintf(diagnostics, "%s\n", "DIGNOSTIC: Fail to delete node from an empty linkedlist.");
	else if (traversePtr == mustGo)
	{
		priorNode->next = traversePtr->next;
		free(traversePtr);
		fprintf(diagnostics, "%s\n", "DIGNOSTIC: Successful to delete node from a linkedlist.")
	else
	{	
		priorNode->next = *traversePtr;
		traversePtr = p2head->next;
	}	
}

void iterate(void *head, ActionFunction doThis)
{
	Node *traversePtr = *head;
	
	while(traversePtr != NULL)
	{
		doThis(traversePtr);
		traversePtr = traversePtr->next;
	}
}
void sort(void *head, ComparisonFunction goesInFrontOf)
{
	Node *previousPtr = *head;
	Node *traversePtr = previousPtr->next;
	int finish = 0;
	int result;
	void *previousData;
	void *traverseData;
	while(finish)
	{
		result = goesInFrontOf(previousPtr, traversePtr);
		if(result > 0)
		{
			traverseData = *(traversePtr->data);
			previousData = *(previousPtr->data);
			*(traversePtr->data) = previousData;
			*(previousPtr->Data) = traverseData;
			previousPtr = previousPtr->next;
			traversePtr = traversePtr->next;
		}
		finish = finish + result;
	}
			
}
