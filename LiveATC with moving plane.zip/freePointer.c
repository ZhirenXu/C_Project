#include "lab3.h"

void freePointer(char *callSign)
{
	free(callSign);
	callSign = NULL;
}
