#include "lab3.h"
#include <math.h>

void calcY()
{
	double speed;
	int deltaY;
	
	speed = Plane.knots * KT_TO_FT;
	deltaY = speed * cos(Plane.heading * M_PI / 180) * DELTA_TIME;
	Plane.y += deltaY;
}
