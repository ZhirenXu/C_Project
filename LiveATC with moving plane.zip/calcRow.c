#include "lab3.h"

int calcRow(double y)
{
	int row;
	int numOfRow;
	int gy;
	
	numOfRow = al_max_Y() - al_min_Y() + 1;
	row = y * numOfRow / STATE_WIDTH_FT;
	gy = al_max_Y() - row;
	
	return gy;
}

