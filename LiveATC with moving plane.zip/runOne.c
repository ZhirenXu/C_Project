#include "lab3.h"

/*
** a function that call other function to do calculating/writing/drawing
**
*/
void runOne()
{
	int time = 0;
	int counter = 1;
	int gx;
	int gy;
	short fl;
	
	while (Plane.x > 0 && Plane.y > 0 )
	{
		gx = calcColumn(Plane.x);
		gy = calcRow(Plane.y);
		fl = calcFL(Plane.alt);
		if (gx >= al_min_X() && gy >= al_min_Y())
		{
			writeFile(time, gx, gy, fl);
			drawPlane(time, gx, gy, fl);
			time = updateClock(counter);
			calcX(time);
			calcY(time);
			counter++;
		}
		else
		{
			break;
		}
	}
}	
