#include "lab3.h"
#include <stdio.h>

/*
** print header line for output file
** @param	out
**		output file
*/
void printErr(FILE *out)
{
	fprintf(out, "\nFailed initialize atc interface!");
}	

