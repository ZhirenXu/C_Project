#include "lab3.h"

int calcColumn(double x)
{ 
	int column;
	int numOfColumn;
	int gx;
	
	numOfColumn = al_max_X() - al_min_X() + 1;
	column = x * numOfColumn / STATE_LENGTH_FT;
	gx = al_min_X() + column;
	
	return gx;
}
	
