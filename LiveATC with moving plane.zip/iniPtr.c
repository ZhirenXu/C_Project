#include "lab3.h"
/*
** initialize all pointers in .h file
*/
void iniPtr(struct Plane_Param p)
{
	p.in = stdin;
	p.out = stdout;
	p.callSign = calloc(14, sizeof(char));
	if (p.callSign == NULL)
	{
		printf("DIGNOSTIC: fail to allocate memory");
	}
	p.sim = malloc(sizeof(struct Sim_Level));
	if (p.sim == NULL)
	{
		printf("DIGNOSTIC: fail to allocate memory");
	}
}
