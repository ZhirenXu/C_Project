#include "libatc.h"
#include "plane.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#define DELTA_TIME 	60			/* update every 60 sec */
#define M_PI		3.14159265358979323846	/* pi */
#define KT_TO_FT	1.687809855643		/* 1 knot to feet */
#define	STATE_LENGTH_FT	2006400			/* length of state in feet */
#define	STATE_WIDTH_FT	1478400			/* width of state in feet */
#define FALSE		0			/* false as 0 */

struct Plane_Param Plane;
int masterSim();
int readFile();
int profile;
void calcX();
void calcY();
int calcColumn(double x);
int calcRow(double y);
short calcFL(double alt);
int updateClock(int counter);
void printHeader(FILE *out);
void printErr(FILE *out);
void runOne();
void writeFile(int time, int gx, int gy, int fl);
void drawGraph(int i, int gx, int gy, char *callSign, double alt, short knots, short heading);
void iniPtr(struct Plane_Param Plane);
void freePointer(char *callSign);
