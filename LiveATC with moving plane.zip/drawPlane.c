#include "libatc.h"
#include "lab3.h"

/* 
** draw plane on ui
*/
void drawPlane(int time, int gx, int gy, short fl)
{
	al_clear();
	al_clock(time);
	al_plane(gx, gy, Plane.callSign, fl, Plane.knots, Plane.heading); 
	al_refresh();
	sleep(1);
}
