#include "lab3.h"

int updateClock(int counter)
{
	int time;
	
	time = DELTA_TIME * counter;
	return time;
}
