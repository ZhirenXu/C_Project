#include "lab3.h"

/*
** Convert altitude(ft) to flight level
** @param	alt
**		plane's altitude(ft)
** @return	fl
**		fight level for that altitude
*/
short calcFL(double alt)
{
	static int TEN = 10;
	static int FIVE = 5;
	int remainder;
	short fl;
	
	fl = alt / 100;
	remainder = fl % 5;
	if (remainder > 5)
	{
		fl += TEN - remainder;
	}
	else 
	{
		fl += FIVE - remainder;
	}
	return fl;
}
