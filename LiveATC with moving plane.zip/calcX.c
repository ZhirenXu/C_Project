#include "lab3.h"
#include <math.h>

void calcX()
{
	double speed;
	int deltaX;
	
	speed = Plane.knots * KT_TO_FT;
	deltaX = speed * sin(Plane.heading * M_PI / 180) * DELTA_TIME;
	Plane.x += deltaX;
}
