#include <stdio.h>
#include "lab3.h"
/*
** Read data from stdin and return an int indicate wheather input is valid.
** @param	in
**		stdin input
** @param	callSign
**		char array of plane callsign
** @param	x
**		plane's location in x axis
** @param	y
**		plane's location in y axis
** @param	alt
**		plane's altitude, in feet
** @param	knots
**		plane's speed, in knots
** @param	heading
**		plane's direction, in degree
** @return	status
**		how many param scanf has read, if not 6 means EOF
*/
int readFile()
{
	int status;
	status = fscanf(Plane.in, "%s %lf %lf %lf %hi %hi", Plane.callSign, &Plane.x, &Plane.y, &Plane.alt, &Plane.knots, &Plane.heading);
	return status;
}
