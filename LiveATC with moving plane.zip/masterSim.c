#include "lab3.h"

/*
** main simulation, responsible for reading plane and run simulation
** @return	when no more plane to read, return 0 as exit signal
*/
int masterSim()
{
	while (readFile(Plane) == 6)
	{
		printHeader(Plane.out);
		runOne();
		fprintf(Plane.out, "\n");
	}
	fprintf(Plane.out, "Failed to read: scanf returnd -1");
	return FALSE;
}
