#include <stdlib.h>
#include <stdio.h>

struct Sim_Level
{
	int elapsedTime;
	void *planeListHead;
};

struct Plane_Param
{ 
	FILE *in; 
	FILE *out;
	char *callSign; 
	double x; 
	double y;
	double alt;
	int ROC;
	int flightProfile;
	short knots;
	short heading;
	struct Sim_Level *sim;
};

