/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALLOF THE WORK TO      
** DETERMINE THE ANSWERS FOUND WITHIN THIS FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON OTHER
** THAN THE INSTRUCTOR OF THIS COURSE OR ONE OF OUR UNDERGRADUATE GRADERS.
*/
#include "lab3.h"
/* author: Zhiren Xu */

int main()
{
	if (al_initialize())
	{
		iniPtr(Plane);
		while (masterSim());
		al_teardown();
	}
	else
	{
		printErr(Plane.out);
	}
	freePointer(Plane.callSign);
	return 0;
}
