#include "lab3.h"

void writeFile(int time, int gx, int gy, int fl)
{
	fprintf(Plane.out, "%5d%s%15s%s%7f%s %7f%s%3d%s%3d%s%f%s%d%5hi%s %s%hi\n", time, "s", Plane.callSign, " (", Plane.x, ",", Plane.y, ") (",  gx, ", ", gy, ") ", Plane.alt, "ft FL", fl, Plane.knots, "K", "H", Plane.heading);
}
