#include "lab3.h"
#include <stdio.h>

/*
** print header line for output file
*/
void printHeader(FILE *out)
{
	fprintf(out, "   ET        Callsign (      x,       y) ( gx,  gy)   Alt   FL    Knots  Deg\n");
}
