#include "lab2.h"

void writeFile(FILE *out, int i, char *callSign, int *x, int *y, int gx, int gy, int *alt, short *knots, short *heading)
{
	int fl;
	int remainder;
	int time = i * DELTA_TIME;
	int TEN = 10;
	int FIVE = 5;
	fl = *alt / 100;
	remainder = fl % 5;
	if (remainder > 5)
	{
		fl += TEN - remainder;
	}
	else 
	{
		fl += FIVE - remainder;
	}
	fprintf(out, "%5d%s%15s%s%7d%s %7d%s%3d%s%3d%s%d%s%d%5hi%s %s%hi\n", time, "s", callSign, " (", *x, ",", *y, ") (",  gx, ", ", gy, ") ", *alt, "ft FL", fl, *knots, "K", "H", *heading);
}
