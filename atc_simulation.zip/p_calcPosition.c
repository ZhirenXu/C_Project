#include <math.h>
#include <stdio.h>
#include "libatc.h"
#define DELTA_TIME 	60
#define M_PI		3.14159265358979323846	/* pi */
#define RATIO		1.687809855643	/* 1 knot to feet */
/*
** This prototype calculate x, y position of jet.
*/
int main()
{
	int x = 1000000;
	int y = 1000000;
	int alt = 35400;
	double speed;
	double deltaY;
	double deltaX;
	short knots = 1396;
	short heading = 225;
	
	speed = knots * RATIO;
	deltaY = speed * cos(heading * M_PI / 180) * DELTA_TIME;
	deltaX = speed * sin(heading * M_PI / 180) * DELTA_TIME;
	printf("(      x,       y)\n");
	while(x >= abs((int)deltaX) && y >= abs((int)deltaY))
	{
		x += lround(deltaX);
		y += lround(deltaY);
		printf("%s%7d%s %7d%s\n", "(", x, ",", y, ")");
	}
	return (0);
}
