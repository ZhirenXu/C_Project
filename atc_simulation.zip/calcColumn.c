#include "lab2.h"
#include <math.h>
#include "libatc.h"
#define	STATE_LENGTH_FT	2006400		/* length of state in feet */
int calcColumn(int *x)
{ 
	float ftPerColumn;
	float column;
	int numOfColumn;
	int gx;
	
	numOfColumn = al_max_X() - al_min_X();
	ftPerColumn = STATE_LENGTH_FT / numOfColumn;
	column = (float)*x / ftPerColumn;
	gx = lround(column) + 1;
	
	return gx;
}
	
