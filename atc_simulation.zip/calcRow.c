#include "lab2.h"
int calcRow(int *y)
{ 
	float ftPerRow;
	float row;
	int numOfWidth;
	int gy;
	
	numOfWidth = al_max_Y() - al_min_Y();
	ftPerRow = STATE_WIDTH_FT / numOfWidth;
	row = (float)*y / ftPerRow;
	gy = lround(row) + 1;
	
	return gy;
}

