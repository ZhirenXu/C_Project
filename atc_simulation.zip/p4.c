#include "libatc.h"

/* 
** THis prototype is to verify libatc drawing ui.
*/

int main()
{
	int ret;
	ret = al_initialize();
	if (ret != 0)
	{
		al_clear();
		al_clock(3723);
		al_plane(40, 9, "Blackbird71", 455, 2200, 45); 
		al_refresh();
		sleep(1);
		getchar();
	}
	al_teardown();
}
