/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALLOF THE WORK TO      
** DETERMINE THE ANSWERS FOUND WITHIN THIS FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON OTHER
** THAN THE INSTRUCTOR OF THIS COURSE OR ONE OF OUR UNDERGRADUATE GRADERS.
*/
#include "lab2.h"
/* author: Zhiren Xu */

int main()
{
	FILE *input;
	FILE *output;
	char *callSign;
	int status;
	int i;
	int *x;
	int *y;
	int gx;
	int gy;
	int isLastX = 0;
	int isLastY = 0;
	int *alt;
	short *knots;
	short *heading;
	
	input = stdin;
	output = stdout;
	callSign = calloc(14, sizeof(char));
	x = malloc(sizeof(int));
	y = malloc(sizeof(int));
	alt = malloc(sizeof(int));
	knots = malloc(sizeof(short));
	heading = malloc(sizeof(short));
	/* check param number and read data */
	status = readFile(input, callSign, x, y, alt, knots, heading);
	
	if (status != 6)
	{
		fprintf(output, "Failed to read: scanf returnd -1");
	}
	else
	{
		fprintf(output, "%s%2d%s%2d%s%2d%s%2d%s","Drawable area is (", al_min_X(), ",", al_min_Y(), ") to (", al_max_X(), ", ", al_max_Y(), ")\n");
	}
	/* calculate position */
	while (status == 6)
	{
		fprintf(output, "   ET        Callsign (      x,       y) ( gx,  gy)   Alt   FL    Knots  Deg\n");
		if (*x > 0 && *y > 0 && *x < STATE_LENGTH_FT && *y < STATE_WIDTH_FT)
		{
			gx = calcColumn(x);
			gy = calcRow(y);
			writeFile(output, i, callSign, x, y, gx, gy, alt, knots, heading);
		}
		while (isLastX == 0 || isLastY == 0)
		{
			isLastX = calcX(x, knots, heading);
			isLastY = calcY(y, knots, heading);
			gx = calcColumn(x);
			gy = calcRow(y);
			i++;
			if (isLastX == 0 && isLastY == 0)
			{
				writeFile(output, i, callSign, x, y, gx, gy, alt, knots, heading);
			}
			else
			{
				fprintf(output, "\n");
				i = 0;
				isLastX = 0;
				isLastY = 0;
				break;
			}
		}
		status = readFile(input, callSign, x, y, alt, knots, heading);
	}
	fprintf(output, "Failed to read: scanf returnd -1\n");
	drawGraph(i, gx, gy, callSign, alt, knots, heading);
	fclose(input);
	fclose(output);
	freePointer(callSign, x, y, alt, knots, heading);
	return 0;
}
