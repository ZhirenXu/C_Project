#include <stdio.h>
#include <stdlib.h>
/*
** This prototype read input file and get all data. printf is to verify if fscanf has been  
** done correctly.
*/
int main()
{
	FILE *input;
	char *callSign;
	int x;
	int y;
	int time = 360;
	int gx = 50;
	int gy = 7;
	int alt;
	int fl = 355;
	short knots;
	short heading;
	
	input = stdin;
	callSign = calloc(14, sizeof(char));
	while (fscanf(input, "%s %d %d %d %hi %hi", callSign, &x, &y, &alt, &knots, &heading) == 6)
	{
		printf("   ET        Callsign (      x,       y) ( gx,  gy)   Alt   FL     Knots  Deg\n");
		printf("%5d%s%15s%s%7d%s %7d%s%3d%s%3d%s%d%s%d %5hi%s %s%hi\n", time, "s", callSign, " (", x, ",", y, ") (",  gx, ", ", gy, ") ", alt, "ft FL", fl, knots, "K", "H", heading);
	}
	fclose(input);
	free(callSign);
	return (0);
}
