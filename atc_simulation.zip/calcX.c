#include "lab2.h"
#include <math.h>
int calcX(int *x, short *knots, short *heading)
{
	double speed;
	double deltaX;
	int isLast = 0;
	
	speed = *knots * KT_TO_FT;
	deltaX = speed * sin(*heading * M_PI / 180) * DELTA_TIME;
	if (*x >= abs((int)deltaX))
	{
		*x += lround(deltaX);
	}
	else
	{
		isLast = 1;
	}
	return isLast;
}
