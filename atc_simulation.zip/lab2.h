#include "libatc.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#define DELTA_TIME 	60			/* update every 60 sec */
#define M_PI		3.14159265358979323846	/* pi */
#define KT_TO_FT	1.687809855643		/* 1 knot to feet */
#define	STATE_LENGTH_FT	2006400			/* length of state in feet */
#define	STATE_WIDTH_FT	1478400			/* width of state in feet */

int readFile(FILE *in, char *callSign, int *x, int *y, int *alt, short *knots, short *heading);
/*
int readX(FILE *in, char *callSign, int x, int y, int alt, short knots, short heading);
int readY(FILE *in, char *callSign, int x, int y, int alt, short knots, short heading);
short readAlt(FILE *in, char *callSign, int x, int y, int alt, short knots, short heading);
short readHeading(FILE *in, char *callSign, int x, int y, int alt, short knots, short heading);
*/
int calcX(int *x, short *knots, short *heading);
int calcY(int *y, short *knots, short *heading);
int calcColumn(int *x);
int calcRow(int *y);
void writeFile(FILE *out, int i, char *callSign, int *x, int *y, int gx, int gy, int *alt, short *knots, short *heading);
void drawGraph(int i, int gx, int gy, char *callSign, int *alt, short *knots, short *heading);
void freePointer(char *callSign, int *x, int *y, int *alt, short *knots, short *heading);
