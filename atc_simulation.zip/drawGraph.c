#include "libatc.h"
#include "lab2.h"

/* 
** draw plane on ui
*/

void drawGraph(int i, int gx, int gy, char *callSign, int *alt, short *knots, short *heading)
{
	int ret;
	int fl;
	int remainder;
	int time = i * DELTA_TIME;
	int TEN = 10;
	int FIVE = 5;
	
	fl = *alt / 100;
	remainder = fl % 5;
	if (remainder > 5)
	{
		fl += TEN - remainder;
	}
	else 
	{
		fl += FIVE - remainder;
	}

	ret = al_initialize();
	if (ret != 0)
	{
		al_clear();
		al_clock(time);
		al_plane(gx, gy, callSign, fl, *knots, *heading); 
		al_refresh();
		sleep(1);
		getchar();
	}
	al_teardown();
}
