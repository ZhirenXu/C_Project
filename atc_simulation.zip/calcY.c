#include "lab2.h"
#include <math.h>
#define DELTA_TIME 	60	/* update every 60 sec */
#define M_PI		3.14159265358979323846	/* pi */
#define KN_TO_FT	1.687809855643	/* 1 knot to feet */

int calcY(int *y, short *knots, short *heading)
{
	double speed;
	double deltaY;
	int isLast = 0;
	
	speed = *knots * KN_TO_FT;
	deltaY = speed * cos(*heading * M_PI / 180) * DELTA_TIME;
	if (*y >= abs((int)deltaY))
	{
		*y += lround(deltaY);
	}
	else
	{
		isLast = 1;
	}
	return isLast;
}
