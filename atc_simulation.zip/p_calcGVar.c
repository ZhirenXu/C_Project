#include "libatc.h"
#include <math.h>
#include <stdio.h>
#define TO_COLUMN	35200	/* 1 column = 35200ft */
#define TO_ROW		70400	/* 1 row = 60400ft */
#define RATIO		1.687809855643	/* 1 knot to feet */
#define DELTA_TIME	60	/* simulate update per 60s */
#define M_PI		3.14159265358979323846	/* pi */
/*
** This prototype calcuate how many rows/column the interface ** should have.
*/
int main()
{
	float speed;
	float deltaY;
	float deltaX;
	float deltaXRatio;
	float deltaYRatio;
	int deltaColumn;
	int deltaRow;
	int max_X = 78;
	int min_X = 22;
	int max_Y = 21;
	int min_Y = 1;
	short knots = 1396;
	short heading = 225;
	float xRatio;
	float yRatio;
	
	speed = (float)knots * RATIO; 
	deltaY = speed * cos(heading * M_PI / 180) * DELTA_TIME;
	deltaX = speed * sin(heading * M_PI / 180) * DELTA_TIME;
	deltaColumn = lround(deltaX / TO_COLUMN);
	deltaRow = lround(deltaY / TO_ROW);
	printf("%s%d %s%d\n", "deltaColumn: ", deltaColumn, "deltaRow: ", deltaRow);
	return 0;
}
