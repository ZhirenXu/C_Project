#include <stdio.h>
#include "lab2.h"
/*
** Read data from stdin and return an int indicate wheather input is valid.
** @param	in
**		stdin input
** @param	callSign
**		char array of plane callsign
** @param	x
**		plane's location in x axis
** @param	y
**		plane's location in y axis
** @param	alt
**		plane's altitude, in feet
** @param	knots
**		plane's speed, in knots
** @param	heading
**		plane's direction, in degree
** @return	status
**		how many param scanf has read, if not 6 means EOF
*/
int readFile(FILE *in, char *callSign, int *x, int *y, int *alt, short *knots, short *heading)
{
	int status;
	status = fscanf(in, "%s %d %d %d %hi %hi", callSign, x, y, alt, knots, heading);
	return status;
}
