#include "lab2.h"

void freePointer(char *callSign, int *x, int *y, int *alt, short *knots, short *heading)
{
	free(callSign);
	free(x);
	free(y);
	free(alt);
	free(knots);
	free(heading);
	callSign = NULL;
	x = NULL;
	y = NULL;
	alt = NULL;
	knots = NULL;
	heading = NULL;
}
