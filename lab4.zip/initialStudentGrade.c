/*
 BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF 
THE WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN 
THIS FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE 
INSTRUCTOR OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE 
TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY. 
*/
#include "lab4.h"
/*
** Give value to each new student node and insert into list.
*/
Node *initialStudentGrade(Node *newStd, char *category_Names, FILE *inputFile){
	int count = 0;
	int status;
	Node *list_Head;
	
	list_Head = malloc(sizeof(Node));	
	if(newStd == NULL){
		printf("fail to alloc space for newStd, program exit.");
		exit(EXIT_FAILURE);
	}else{
		/* when status=-1, class_record is at EOF */
		while(status != -1){		
			status = getStudentGrade(newStd, inputFile);
			/* put new node into linked list */
			if(status != -1){
				insertNodeToList(&list_Head, newStd);
				count++;
			}
		}
		newStd->next = NULL;
	}
	printf("%s%d%s\n\n\n\n", "There are ", count, " students records been read in.");
	return list_Head;
}
