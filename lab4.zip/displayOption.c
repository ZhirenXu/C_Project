/*
 BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF 
THE WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN 
THIS FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE 
INSTRUCTOR OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE 
TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY. 
*/
#include "lab4.h"
/*
** Prompt all options and return the option usser chosed.
** @return the option user chosed.
*/ 
int displayOption(){
	int i = 1;
	int response;
	printf("Please enter an option between 1 and 10: \n");
	printf("%d%s", i, ". Print Student Scores by Student ID\n");
	i++;
	printf("%d%s", i, ". Print Student Scores by Last Name\n");
	i++;
	printf("%d%s", i, ". Print Student Scores for All Students\n");
	i++;
	printf("%d%s", i, ". Recalculate Student Scores for a Single Student ID\n");
	i++;
	printf("%d%s", i, ". Recalculate all Student Scores\n");
	i++;
	printf("%d%s", i, ". Insert a score for a specific Student ID\n");
	i++;
	printf("%d%s", i, ". Calculate Final Grades\n");
	i++;
	printf("%d%s", i, ". Add a new student\n");
	i++;
	printf("%d%s", i, ". Delete a student\n");
	i++;
	printf("%d%s", i, ". Exit Program\n\n\n\n\n");
	printf("Option: ");
	scanf("%i", &response);
	return response;
}
