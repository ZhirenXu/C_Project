/*
 BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF 
THE WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN 
THIS FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE 
INSTRUCTOR OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE 
TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY. 
*/
#include "lab4.h"
/*
** print student record in one line via last name.
** @param *head
**		The list head of studentPtr
** @param *Category_Names
**		Different kind of student grade category
*/
void printLineViaLastName(Node *head, char *Category_Names)
{
	Node *NodePtr;
	char *stdLastName;
	int i;
#ifdef DEBUG
	printf("Student Data. Head List is %x\n", head);
#endif
	/* get StdLastName  from user	*/
	stdLastName = calloc(40, sizeof(char));
	printf("Enter the Student last name: ");
	/* keep get input until read '\n' */
	i = 0;
	scanf("%s", stdLastName);
	printf("Hunting for %s\n", stdLastName);

	/* look for the correct student Node */
	NodePtr = getNodeforLastName(&head, stdLastName);

	/* we found it or not	*/
	if(NodePtr == NULL){
		printf("\nERROR: Student last name %s was not found in the list\n", stdLastName);
	}
	else {
		printHeader(Category_Names);
		printStudent(NodePtr);
		printf("\n");
	}
	free(stdLastName);
}

