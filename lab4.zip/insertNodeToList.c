/*
 BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF 
THE WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN 
THIS FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE 
INSTRUCTOR OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE 
TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY. 
*/
#include "lab4.h"
/*
** Insert a node into student list.
** @param *listHeadPtr
**		the start node of student linked list
** @param *newStdNode
** 		the node need to be inserted into the list
*/
void insertNodeToList(Node **listHead, Node *newStdNode){
		Node *traversePtr;
		traversePtr = *listHead;
		/* when list is empty */
		if(listHead == NULL){
			*listHead = newStdNode;
			newStdNode->next = NULL;
		/* when list has content */
		}else{
			newStdNode->next = *listHead;
			*listHead = newStdNode;
		}
}
