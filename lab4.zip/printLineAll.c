/*
 BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF 
THE WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN 
THIS FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE 
INSTRUCTOR OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE 
TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY. 
*/
#include "lab4.h"
/* 
** print all student scores.
** @param *head
**		The list head of student grade
** @param *Category_Names
**		Pointer of different grade category
*/
void printLineAll(Node *head, char *Category_Names)
{
	Node *traversePtr;
	traversePtr = malloc(sizeof(Node));
	traversePtr = head;
	if(traversePtr == NULL){
		printf("Student Data. Head List is %x\n", head);
	}else{
		printHeader(Category_Names);
		while(traversePtr != NULL){
			printStudent(traversePtr);
			printf("%.2f\t", traversePtr->Student.Current_Grade);
			if(traversePtr->Student.Final_Grade == -1){
				printf("n/a\t");
				printf("\n");
			}else{
				printf("%.2f\n", traversePtr->Student.Final_Grade);
			}
			traversePtr = traversePtr->next;
		}
		printf("\n");
	}
}

