/*
 BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF 
THE WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN 
THIS FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE 
INSTRUCTOR OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE 
TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY. 
*/
#include "lab4.h"
/*
** open and read a file contains student grade, get value of each item to student node.
** @param newStdPtr
**		The student node that need to get data
** @param inputFile
**		The file this function open and read data from
** @return 0 if data is found and applied to node, -1 if $EOF
*/
int getStudentGrade(Node *newStdPtr, FILE *inputFile){
	int i;
	int counter = 0;
	char *content;
	float finalCumGrade[4];
	float catCumRatio[4];
	catCumRatio[0] = 0.15;
	catCumRatio[1] = 0.3;
	catCumRatio[2] = 0.2;
	catCumRatio[3] = 0.35;
	
	content = calloc(256, sizeof(char));
	if(inputFile == NULL){
		perror("Fail to open class record.");
		exit(EXIT_FAILURE);
	}
	if(newStdPtr == NULL){
		printf("Space allocated for newStdPtr fail! Program exit.");
		exit(EXIT_FAILURE);
	}else{
		/* when at EOF */
		if(fscanf(inputFile, " %[^\n]", newStdPtr->Student.student_name) == EOF){
			return -1;
		}else{
			/* set finish grade to -1 */
			newStdPtr->Student.Final_Grade = (int)(-1);
		/* get Cat1 grade */		
			fscanf(inputFile, "%d", &(newStdPtr->Student.student_ID));
			fscanf(inputFile, "%f %f %f", &(newStdPtr->Student.Cat1.score1), &(newStdPtr->Student.Cat1.score2), &(newStdPtr->Student.Cat1.score3));
			if((int)(newStdPtr->Student.Cat1.score1) == -1){
				counter++;
			}
			if((int)(newStdPtr->Student.Cat1.score2) == -1){
				counter++;
			}
			if((int)(newStdPtr->Student.Cat1.score3) == -1){
				counter++;
			}
			/* calculate Cumulative */
			switch (counter){
				case 1 :
					newStdPtr->Student.Cat1.Cumulative = (newStdPtr->Student.Cat1.score1 + newStdPtr->Student.Cat1.score2 + newStdPtr->Student.Cat1.score3 + 1)/2;
					finalCumGrade[0] = newStdPtr->Student.Cat1.Cumulative;
				break;
				case 2 :
					newStdPtr->Student.Cat1.Cumulative = newStdPtr->Student.Cat1.score1 + newStdPtr->Student.Cat1.score2 + newStdPtr->Student.Cat1.score3 + 2;
					finalCumGrade[0] = newStdPtr->Student.Cat1.Cumulative;
				break;
				case 3 :
					newStdPtr->Student.Cat1.Cumulative = -1;
					finalCumGrade[0] = 100;
				break;
				default :
					newStdPtr->Student.Cat1.Cumulative = (newStdPtr->Student.Cat1.score1 + newStdPtr->Student.Cat1.score2 + newStdPtr->Student.Cat1.score3)/3;
					finalCumGrade[0] = newStdPtr->Student.Cat1.Cumulative;
			}
			counter = 0;
			/* get Cat2 grade */
			fscanf(inputFile, "%f %f %f", &(newStdPtr->Student.Cat2.score1), &(newStdPtr->Student.Cat2.score2), &(newStdPtr->Student.Cat2.score3));
			if((int)newStdPtr->Student.Cat2.score1 == -1){
				counter++;
			}
			if((int)newStdPtr->Student.Cat2.score2 == -1){
				counter++;
			}
			if((int)newStdPtr->Student.Cat2.score3 == -1){
				counter++;
			}	
			/* calculate Cumulative */
			switch (counter){
				case 1 :
					newStdPtr->Student.Cat2.Cumulative = (newStdPtr->Student.Cat2.score1 + newStdPtr->Student.Cat2.score2 + newStdPtr->Student.Cat2.score3 + 1)/2;
					finalCumGrade[1] = newStdPtr->Student.Cat2.Cumulative;
				break;
				case 2 :
					newStdPtr->Student.Cat2.Cumulative = newStdPtr->Student.Cat2.score1 + newStdPtr->Student.Cat2.score2 + newStdPtr->Student.Cat2.score3 + 2;
					finalCumGrade[1] = newStdPtr->Student.Cat2.Cumulative;
				break;
				case 3 :
					newStdPtr->Student.Cat2.Cumulative = -1;
					finalCumGrade[1] = 100;
				break;
				default :
					newStdPtr->Student.Cat2.Cumulative = (newStdPtr->Student.Cat2.score1 + newStdPtr->Student.Cat2.score2 + newStdPtr->Student.Cat2.score3)/3;
					finalCumGrade[1] = newStdPtr->Student.Cat2.Cumulative;
			}
			counter = 0;
			/* get Cat3 grade */
			fscanf(inputFile, "%f %f %f", &(newStdPtr->Student.Cat3.score1), &(newStdPtr->Student.Cat3.score2), &(newStdPtr->Student.Cat3.score3));
			if((int)(newStdPtr->Student.Cat3.score1) == -1){
				counter++;
			}
			if((int)(newStdPtr->Student.Cat3.score2) == -1){
				counter++;
			}
			if((int)(newStdPtr->Student.Cat3.score3) == -1){
				counter++;
			}	
			/* calculate Cumulative */
			switch (counter){
				case 1 :
					newStdPtr->Student.Cat3.Cumulative = (newStdPtr->Student.Cat3.score1 + newStdPtr->Student.Cat3.score2 + newStdPtr->Student.Cat3.score3 + 1)/2;
					finalCumGrade[2] = newStdPtr->Student.Cat3.Cumulative;
				break;
				case 2 :
					newStdPtr->Student.Cat3.Cumulative = newStdPtr->Student.Cat3.score1 + newStdPtr->Student.Cat3.score2 + newStdPtr->Student.Cat3.score3 + 2;
					finalCumGrade[2] = newStdPtr->Student.Cat3.Cumulative;
				break;
				case 3 :
					newStdPtr->Student.Cat3.Cumulative = -1;
					finalCumGrade[2] = 100;
				break;
				default :
					newStdPtr->Student.Cat3.Cumulative = (newStdPtr->Student.Cat3.score1 + newStdPtr->Student.Cat3.score2 + newStdPtr->Student.Cat3.score3)/3;
					finalCumGrade[2] = newStdPtr->Student.Cat3.Cumulative;
			}
			counter = 0;
			/* get cat4 grade */
			fscanf(inputFile, "%f %f %f", &(newStdPtr->Student.Cat4.score1), &(newStdPtr->Student.Cat4.score2), &(newStdPtr->Student.Cat4.score3));
			if((int)newStdPtr->Student.Cat4.score1 == -1){
				counter++;
			}
			if((int)newStdPtr->Student.Cat4.score2 == -1){
				counter++;
			}
			if((int)newStdPtr->Student.Cat4.score3 == -1){
				counter++;
			}	
			/* calculate Cumulative */
			switch (counter){
				case 1 :
					newStdPtr->Student.Cat4.Cumulative = (newStdPtr->Student.Cat4.score1 + newStdPtr->Student.Cat4.score2 + newStdPtr->Student.Cat4.score3 + 1)/2;
					finalCumGrade[3] = newStdPtr->Student.Cat4.Cumulative;
				break;
				case 2 :
					newStdPtr->Student.Cat4.Cumulative = newStdPtr->Student.Cat4.score1 + newStdPtr->Student.Cat4.score2 + newStdPtr->Student.Cat4.score3 + 2;
					finalCumGrade[3] = newStdPtr->Student.Cat4.Cumulative;
				break;
				case 3 :
					newStdPtr->Student.Cat4.Cumulative = -1;
					finalCumGrade[3] = 100;
				break;
				default :
					newStdPtr->Student.Cat4.Cumulative = (newStdPtr->Student.Cat4.score1 + newStdPtr->Student.Cat4.score2 + newStdPtr->Student.Cat4.score3)/3;
					finalCumGrade[3] = newStdPtr->Student.Cat4.Cumulative;
			}
			counter = 0;
			/* calculate Current_Grade */
			for(i = 0; i < 4; i++){
				newStdPtr->Student.Current_Grade += catCumRatio[i] * finalCumGrade[i];
			}
		}
	}
	return 0;
}
