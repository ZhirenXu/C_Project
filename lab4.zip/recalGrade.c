/*
 BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF 
THE WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN 
THIS FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE 
INSTRUCTOR OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE 
TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY. 
*/
#include "lab4.h"
/*
** recalculate a student's grades and print them out.
** @param *listHead
**		The list head of student grade
** @param *Category_Names
**		The name of student grade Category
*/
void recalGrade(Node *listHead, char *Category_Names){
	Node *nodePtr;
	int studentID;
	int counter;
	int i;
	float finalCumGrade[4];
	float catCumRatio[4];
	catCumRatio[0] = 0.15;
	catCumRatio[1] = 0.3;
	catCumRatio[2] = 0.2;
	catCumRatio[3] = 0.35;
	
	/* get studentID to use from user	*/
	printf("What is the student ID for the scores you want to recalculate?\n");
	printf("StudentID: ");
	scanf("%i", &studentID);
	/* print basic info	*/
	nodePtr = malloc(sizeof(Node));
	nodePtr = getNodeForID(&listHead, studentID);
	printf("%s%s%s%i\n", "Recalculate grade for ", nodePtr->Student.student_name, " Student ID number: ", studentID);
	
	/* recalculate Cat1 cumulatives */
	counter = 0;
	if((int)(nodePtr->Student.Cat1.score1) == -1){
		counter++;
	}
	if((int)(nodePtr->Student.Cat1.score2) == -1){
		counter++;
	}
	if((int)(nodePtr->Student.Cat1.score3) == -1){
		counter++;
	}
	switch (counter){
		case 1 :
			nodePtr->Student.Cat1.Cumulative = (nodePtr->Student.Cat1.score1 + nodePtr->Student.Cat1.score2 + nodePtr->Student.Cat1.score3 + 1)/2;
			finalCumGrade[0] = nodePtr->Student.Cat1.Cumulative;
			break;
		case 2 :
			nodePtr->Student.Cat1.Cumulative = nodePtr->Student.Cat1.score1 + nodePtr->Student.Cat1.score2 + nodePtr->Student.Cat1.score3 + 2;
			finalCumGrade[0] = nodePtr->Student.Cat1.Cumulative;
			break;
		case 3 :
			nodePtr->Student.Cat1.Cumulative = -1;
			finalCumGrade[0] = 100;
			break;
		default :
			nodePtr->Student.Cat1.Cumulative = (nodePtr->Student.Cat1.score1 + nodePtr->Student.Cat1.score2 + nodePtr->Student.Cat1.score3)/3;
			finalCumGrade[0] = nodePtr->Student.Cat1.Cumulative;
	}
	counter = 0;
			
	/* recalculate Cat2 cumulatives */
	if((int)(nodePtr->Student.Cat2.score1) == -1){
		counter++;
	}
	if((int)(nodePtr->Student.Cat2.score2) == -1){
		counter++;
	}
	if((int)(nodePtr->Student.Cat2.score3) == -1){
		counter++;
	}
	switch (counter){
		case 1 :
			nodePtr->Student.Cat2.Cumulative = (nodePtr->Student.Cat2.score1 + nodePtr->Student.Cat2.score2 + nodePtr->Student.Cat2.score3 + 1)/2;
			finalCumGrade[1] = nodePtr->Student.Cat2.Cumulative;
			break;
		case 2 :
			nodePtr->Student.Cat2.Cumulative = nodePtr->Student.Cat2.score1 + nodePtr->Student.Cat2.score2 + nodePtr->Student.Cat2.score3 + 2;
			finalCumGrade[1] = nodePtr->Student.Cat2.Cumulative;
			break;
		case 3 :
			nodePtr->Student.Cat2.Cumulative = -1;
			finalCumGrade[1] = 100;
			break;
		default :
			nodePtr->Student.Cat2.Cumulative = (nodePtr->Student.Cat2.score1 + nodePtr->Student.Cat2.score2 + nodePtr->Student.Cat2.score3)/3;
			finalCumGrade[1] = nodePtr->Student.Cat2.Cumulative;
			counter = 0;
	}
			
	/* recalculate Cat3 cumulatives */
	if((int)(nodePtr->Student.Cat3.score1) == -1){
		counter++;
	}
	if((int)(nodePtr->Student.Cat3.score2) == -1){
		counter++;
	}
	if((int)(nodePtr->Student.Cat3.score3) == -1){
		counter++;
	}
	switch (counter){
		case 1 :
			nodePtr->Student.Cat3.Cumulative = (nodePtr->Student.Cat3.score1 + nodePtr->Student.Cat3.score2 + nodePtr->Student.Cat3.score3 + 1)/2;
			finalCumGrade[2] = nodePtr->Student.Cat3.Cumulative;
			break;
		case 2 :
			nodePtr->Student.Cat3.Cumulative = nodePtr->Student.Cat3.score1 + nodePtr->Student.Cat3.score2 + nodePtr->Student.Cat3.score3 + 2;
			finalCumGrade[2] = nodePtr->Student.Cat3.Cumulative;
			break;
		case 3 :
			nodePtr->Student.Cat3.Cumulative = -1;
			finalCumGrade[2] = 100;
			break;
		default :
			nodePtr->Student.Cat3.Cumulative = (nodePtr->Student.Cat3.score1 + nodePtr->Student.Cat3.score2 + nodePtr->Student.Cat3.score3)/3;
			finalCumGrade[2] = nodePtr->Student.Cat3.Cumulative;
	}
	counter = 0;
	
	/* recalculate Cat4 cumulatives */
	if((int)(nodePtr->Student.Cat4.score1) == -1){
		counter++;
	}
	if((int)(nodePtr->Student.Cat4.score2) == -1){
		counter++;
	}
	if((int)(nodePtr->Student.Cat4.score3) == -1){
		counter++;
	}
	switch (counter){
		case 1 :
			nodePtr->Student.Cat4.Cumulative = (nodePtr->Student.Cat4.score1 + nodePtr->Student.Cat4.score2 + nodePtr->Student.Cat4.score3 + 1)/2;
			finalCumGrade[3] = nodePtr->Student.Cat4.Cumulative;
			break;
		case 2 :
			nodePtr->Student.Cat4.Cumulative = nodePtr->Student.Cat4.score1 + nodePtr->Student.Cat4.score2 + nodePtr->Student.Cat4.score3 + 2;
			finalCumGrade[3] = nodePtr->Student.Cat4.Cumulative;
			break;
		case 3 :
			nodePtr->Student.Cat4.Cumulative = -1;
			finalCumGrade[3] = 100;
			break;
		default :
			nodePtr->Student.Cat4.Cumulative = (nodePtr->Student.Cat4.score1 + nodePtr->Student.Cat4.score2 + nodePtr->Student.Cat4.score3)/3;
			finalCumGrade[3] = nodePtr->Student.Cat4.Cumulative;
	}
	counter = 0;
			
	/* recalculate current grade */
	/* reset score */
	nodePtr->Student.Current_Grade = 0;
	for(i = 0; i < 4; i++){
		nodePtr->Student.Current_Grade += catCumRatio[i] * finalCumGrade[i];
	}
	
	/* print out new grade */
	printf("%s%s%.2f\n", Category_Names, " Cumlative: ", nodePtr->Student.Cat1.Cumulative);
	printf("%s%s%.2f\n", (char *)Category_Names+15, " Cumlative: ", nodePtr->Student.Cat2.Cumulative);
	printf("%s%s%.2f\n", (char *)Category_Names+30, " Cumlative: ", nodePtr->Student.Cat3.Cumulative);
	printf("%s%s%.2f\n", (char *)Category_Names+45, " Cumlative: ", nodePtr->Student.Cat4.Cumulative);
	printf("%s%.2f\n", "Current Garde is: ", nodePtr->Student.Current_Grade);
	printf("Student's Final Grade was deleted\n");
	printf("\n");
}
