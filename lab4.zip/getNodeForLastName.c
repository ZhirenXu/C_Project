/*
 BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF 
THE WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN 
THIS FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE 
INSTRUCTOR OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE 
TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY. 
*/
#include "lab4.h"
#include <string.h>
/* given a specific student ID, this program
 * returns the address of the Node for that student
 */
Node *getNodeforLastName(Node **head, char *studentLastName){

	Node *traversePtr;
	char *ret;
	/* travel through the linked list looking for the studentID	*/
	traversePtr = *head;
	while(traversePtr!=NULL){
		ret = strstr(traversePtr->Student.student_name, studentLastName);
		if (ret != NULL) {
		/* found it!  return the address to the Node	*/
			return traversePtr;
		}
		traversePtr = traversePtr->next;
	}
	/* no Node in the linked list with that StudentID	*/
	return NULL;
}
