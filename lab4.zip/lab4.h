/*
 BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF 
THE WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN 
THIS FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE 
INSTRUCTOR OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE 
TENURES OF THE OHIO STATE UNIVERSITY?S ACADEMIC INTEGRITY POLICY. 
*/
#include <stdio.h>
#include <stdlib.h>

struct Cat_Grade{ 
	float score1; 
	float score2; 
	float score3; 
	float Cumulative; 
}; 
struct Data { 
	char student_name[40];
	int student_ID;             
	struct Cat_Grade Cat1;
	struct Cat_Grade Cat2;
	struct Cat_Grade Cat3;
	struct Cat_Grade Cat4;
	float Current_Grade;
	float Final_Grade;
};
typedef struct Node {
	struct Data Student;
	struct Node *next;
} Node;

void printLine(Node *head, char *Category_Names);
void printLineViaLastName(Node *head, char *Category_Names);
void printLineAll(Node *head, char *Category_Names);
void printHeader(char *Category_Names);
void printStudent(Node *student);
void recalGrade(Node *listHead, char *category_Names);
void recalAllGrade(Node *listHead, char *category_Names);
void insertRecord(Node *listHead, char *category);
void calcFinalGrade(Node *listHead, char *Category_Names);
Node *initialStudentGrade(Node *newStdPtr, char *categoryNames, FILE *input);
void deleteStd(Node **listHead);
void saveToFile(FILE *output, Node **listHead, char *category);
int displayOption();
Node *getNodeforLastName(Node **head, char *studentLastName);
Node *getNodeForID(Node **head, int StudentID);
