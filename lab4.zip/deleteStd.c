/*
 BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF 
THE WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN 
THIS FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE 
INSTRUCTOR OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE 
TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY. 
*/
#include "lab4.h"
/*
** Find student Node via ID and delete it.
** @param listHead
**		The start of student linked list
*/
void deleteStd(Node **listHead){
	int stdID;
	int option;
	char *stdName;
	Node *stdPtr;
	Node *priorNode;
	Node *traversePtr;
	/* get student ID */
	stdName = calloc(40, sizeof(char));
	traversePtr = malloc(sizeof(Node));
	printf("Please enter the student ID number you wish to delete, follow by enter.\n");
	scanf("%i", &stdID);
	/* travel through the linked list looking for the studentID	*/
	traversePtr = *listHead;
	while(traversePtr!=NULL){
		if (traversePtr->Student.student_ID == stdID) {
		/* found it!  return the address to the Node	*/
			stdPtr = traversePtr;
			break;
		}
		traversePtr = traversePtr->next;
	}
	stdName = stdPtr->Student.student_name;
	printf("%s%i%s%s%s", "Do you really want to delete student ID number ", stdID, " ", stdPtr->Student.student_name, " ?\n");
	printf("If yes, enter 1. If no , enter 2: ");
	scanf("%i", &option);
	/* delete node */
	if(option == 1){
		traversePtr = *listHead;
		/* when list is empty */
		if(traversePtr == NULL){
			printf("There are no nodes, nothing to delete!");
		}else{
			/* when stdPtr is the first node */
			if(traversePtr == stdPtr){
				*listHead = traversePtr->next;
				free(traversePtr);
			}else{
				/* delete note from the middle of student list */
				priorNode = malloc(sizeof(Node));
				while(traversePtr != stdPtr){
					priorNode = traversePtr;
					traversePtr  = traversePtr->next;
					if(traversePtr == NULL){
						printf("This node is not in the list");
						break;
					}
				}
				/* when find the node */
				priorNode->next = traversePtr->next;
				free(traversePtr);		
				printf("%s%i%s%s", "Student ID number ", stdID, ", ", stdName, " has been deleted.\n");
				free(priorNode);
			}
		}
	}
}
