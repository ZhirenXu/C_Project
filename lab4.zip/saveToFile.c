/*
 BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF 
THE WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN 
THIS FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE 
INSTRUCTOR OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE 
TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY. 
*/
#include "lab4.h"
/*
** Save all student record to a file and exit the program.
** @param output
**		user pointed output file
** @param listHead
**		the beginning of student linnked list
** @param category
**		provide name of grade category
*/
void saveToFile(FILE *output, Node **listHead, char *category){
	Node *traversePtr;
	int counter;
	if(output != NULL){
		/* write category info */
		fprintf(output, "%s%s", category, " ");
		fprintf(output, "%s%s", category+15, " ");
		fprintf(output, "%s%s", category+30, " ");
		fprintf(output, "%s%s\n", category+45, " ");
		traversePtr = malloc(sizeof(Node));
		traversePtr = *listHead;
		counter = 0;
		/* write student info */
		while(traversePtr != NULL){
			fprintf(output, "%s\n", traversePtr->Student.student_name);
			fprintf(output, "%i\n", traversePtr->Student.student_ID);
			fprintf(output, "%.2f\t%.2f\t%.2f\n", traversePtr->Student.Cat1.score1, traversePtr->Student.Cat1.score2, traversePtr->Student.Cat1.score3);
			fprintf(output, "%.2f\t%.2f\t%.2f\n", traversePtr->Student.Cat2.score1, traversePtr->Student.Cat2.score2, traversePtr->Student.Cat2.score3);
			fprintf(output, "%.2f\t%.2f\t%.2f\n", traversePtr->Student.Cat3.score1, traversePtr->Student.Cat3.score2, traversePtr->Student.Cat3.score3);
			fprintf(output, "%.2f\t%.2f\t%.2f\n", traversePtr->Student.Cat4.score1, traversePtr->Student.Cat4.score2, traversePtr->Student.Cat4.score3);
			traversePtr = traversePtr->next;
			counter++;
		}
		/* print exit message */
		printf("%s%i%s", "A total of ", counter, " student records were written to file ");
	}
	fclose(output);
	free(traversePtr);
}	
