/*
 BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF 
THE WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN 
THIS FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE 
INSTRUCTOR OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE 
TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY. 
*/
#include "lab4.h"
/* 
** insert a new student grade.
** @param *listhead
**		The list head of student grade
** @param *Category_Names
**		Pointer of different grade category
*/
void insertRecord(Node *listHead, char *category){
	int studentID;
	Node *stdPtr;
	int insertChoice;
	int categoryChoice;
	int scoreChoice;
	
	stdPtr = malloc(sizeof(Node));
	printf("Enter the student ID #: ");
	scanf("%i", &studentID);
	printf("Hunting for %d\n", studentID);
	stdPtr = getNodeForID(&listHead, studentID);
	/* lf node is not found */
	if(stdPtr == NULL){
		printf("\nERROR: Student ID number %i was not found in the list\n",studentID);
	}else{
		/* if node has been found */
		printf("%s%s%s", "Insert a score for ", stdPtr->Student.student_name, " ? Enter 1, if yes. Enter 2, if no: ");
		scanf("%i", &insertChoice);
		/* change score */
		if(insertChoice == 1){
			printf("Which category?\n1) Quizzes\n2) Midterms\n3) Homework\n4) Final\n");
			scanf("%i", &categoryChoice);
			printf("Which score?\nEnter 1, 2, or 3\n");
			scanf("%i", &scoreChoice);
			/* insert new score */
			printf("Enter New Score: ");
			switch(categoryChoice){
				case 1:
					if(scoreChoice == 1){
						scanf("%f", &stdPtr->Student.Cat1.score1);
					}else if(scoreChoice == 2){
						scanf("%f", &stdPtr->Student.Cat1.score2);
					}else if(scoreChoice == 3){
						scanf("%f", &stdPtr->Student.Cat1.score3);
					}
					break;
				case 2:
					if(scoreChoice == 1){
						scanf("%f", &stdPtr->Student.Cat2.score1);
					}else if(scoreChoice == 2){
						scanf("%f", &stdPtr->Student.Cat2.score2);
					}else if(scoreChoice == 3){
						scanf("%f", &stdPtr->Student.Cat2.score3);
					}
					break;
				case 3:
					if(scoreChoice == 1){
						scanf("%f", &stdPtr->Student.Cat3.score1);
					}else if(scoreChoice == 2){
						scanf("%f", &stdPtr->Student.Cat3.score2);
					}else if(scoreChoice == 3){
						scanf("%f", &stdPtr->Student.Cat3.score3);
					}
					break;
				case 4:
					if(scoreChoice == 1){
						scanf("%f", &stdPtr->Student.Cat4.score1);
					}else if(scoreChoice == 2){
						scanf("%f", &stdPtr->Student.Cat4.score2);
					}else if(scoreChoice == 3){
						scanf("%f", &stdPtr->Student.Cat4.score3);
					}
					break;
				default:
					break;
			}
			/* print new student record */
			printHeader(category);
			printStudent(stdPtr);
			printf("\n");
			printf("Note: Category Cums, Current Grade and Final Grade have not been recalculated based on the new value entered.\n");
			printf("\n");
		}
	}
	free(stdPtr);
}
