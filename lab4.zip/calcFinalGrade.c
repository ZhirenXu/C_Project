/*
 BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF 
THE WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN 
THIS FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE 
INSTRUCTOR OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE 
TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY. 
*/
#include <stdio.h>
#include <stdlib.h>
#include "lab4.h"
/* 
** calculate and print all student final scores.
** @param *listhead
**		The list head of student grade
** @param *Category_Names
**		Pointer of different grade category
*/
void calcFinalGrade(Node *listHead, char *Category_Names){
	Node *traversePtr;
	int counter = 0;
	float classCat1Avg = 0;
	float classCat2Avg = 0;
	float classCat3Avg = 0;
	float classCat4Avg = 0;
	float classFinalAvg = 0;
	float catCumRatio[4];
	catCumRatio[0] = 0.15;
	catCumRatio[1] = 0.3;
	catCumRatio[2] = 0.2;
	catCumRatio[3] = 0.35;
	
	traversePtr = malloc(sizeof(Node));
	traversePtr = listHead;
	/* if fail to find any student */
	if(traversePtr == NULL){
		printf("Student Data. Head List is %x\n", listHead);
	}else{
		/* initialization */
		traversePtr->Student.Final_Grade = 0;
		printHeader(Category_Names);
		/* print student grade till the end */
		while(traversePtr != NULL){
			/* calculate Final_Grade */
			/* Cat1 */
			if(traversePtr->Student.Cat1.Cumulative == -1){
				traversePtr->Student.Final_Grade += 0;
			}else{
				traversePtr->Student.Final_Grade += (catCumRatio[0] * traversePtr->Student.Cat1.Cumulative);
			}
			/* Cat2 */
			if(traversePtr->Student.Cat2.Cumulative == -1){
				traversePtr->Student.Final_Grade += 0;
			}else{
				traversePtr->Student.Final_Grade += (catCumRatio[1] * traversePtr->Student.Cat2.Cumulative);
			}
			/* Cat3 */
			if(traversePtr->Student.Cat3.Cumulative == -1){
				traversePtr->Student.Final_Grade += 0;
			}else{
				traversePtr->Student.Final_Grade += (catCumRatio[2] * traversePtr->Student.Cat3.Cumulative);
			}
			/* Cat4 */
			if(traversePtr->Student.Cat4.Cumulative == -1){
				traversePtr->Student.Final_Grade += 0;
			}else{
				traversePtr->Student.Final_Grade += (catCumRatio[3] * traversePtr->Student.Cat4.Cumulative);
			}
			printStudent(traversePtr);
			
			/* print Final_Grade */
			printf("%.2f\t", traversePtr->Student.Current_Grade);
			printf("%.2f\n", traversePtr->Student.Final_Grade);
			/* add to class avg */
			classCat1Avg += traversePtr->Student.Cat1.Cumulative;
			classCat2Avg += traversePtr->Student.Cat2.Cumulative;
			classCat3Avg += traversePtr->Student.Cat3.Cumulative;
			classCat4Avg += traversePtr->Student.Cat4.Cumulative;
			classFinalAvg += traversePtr->Student.Final_Grade;
			traversePtr = traversePtr->next;
			counter++;
		}
		/* calculate class avg */
		classCat1Avg = classCat1Avg/counter;
		classCat2Avg = classCat2Avg/counter;
		classCat3Avg = classCat3Avg/counter;
		classCat4Avg = classCat4Avg/counter;
		classFinalAvg = classFinalAvg/counter;
		printf("\n\n");
		printf("%s%s%s%.2f%s%s%s%.2f%s%s%s%.2f%s%s%s%.2f%s%s%.2f\n", "Class Average for ", Category_Names, " : ", classCat1Avg, ", ", Category_Names+15, ": ", classCat2Avg, ", ", Category_Names+30, ": ", classCat3Avg, ", ", Category_Names+45, ": ", classCat4Avg, ", ", "Current Grade: ", classFinalAvg);
	}
	free(traversePtr);
}
