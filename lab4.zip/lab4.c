/*
 BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF 
THE WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN 
THIS FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE 
INSTRUCTOR OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE 
TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY. 
*/
#include <stdio.h>
#include <stdlib.h>
#include "lab4.h"
/* Author: Zhiren Xu */

int main(int argc, char *argv[]){
	char *category;
	Node *listHead = NULL;
	Node *newStd;
	FILE *inputFile;
	FILE *outputFile;
	int option;
	int ctrl;
	void (*choice[7])(Node *, char *);
	
	if(argc > 0){
		ctrl = 1;
		category = calloc(60, sizeof(char));
		newStd = malloc(sizeof(Node));
		inputFile = fopen(argv[1], "r");
		fscanf(inputFile, "%s", category);
		fscanf(inputFile, "%s", category+15);
		fscanf(inputFile, "%s", category+30);
		fscanf(inputFile, "%s", category+45);
		printf("%s%s%s\n", "Reading student information from file \"", argv[1], "\"");
		listHead = initialStudentGrade(newStd, category, inputFile);
		option = displayOption();
		
		/* Assign function to function pointer */
		choice[0] = printLine;
		choice[1] = printLineViaLastName;
		choice[2] = printLineAll;
		choice[3] = recalGrade;
		choice[4] = recalAllGrade;
		choice[5] = insertRecord;
		choice[6] = calcFinalGrade; 
		
		while(ctrl){
			switch(option){
			case 1:
				choice[0](listHead, category);
				printf("\n\n\n\n");
				break;
			case 2:
				choice[1](listHead, category);
				printf("\n\n\n\n");
				break;
			case 3:
				choice[2](listHead, category);
				printf("\n\n\n\n");
				break;
			case 4:
				choice[3](listHead, category);
				printf("\n\n\n\n");
				break;
			case 5:
				choice[4](listHead, category);
				printf("\n\n\n\n");
				break;
			case 6:
				choice[5](listHead, category);
				break;
			case 7:
				choice[6](listHead, category);
				printf("\n\n\n\n");
				break;
			case 8:
				insertNewStd(&listHead, category);
				printf("\n\n\n\n");
				break;
			case 9:
				deleteStd(&listHead);
				printf("\n\n\n\n");
				break;
			case 10:
				fclose(inputFile);
				outputFile = fopen(argv[2], "w");
				saveToFile(outputFile, &listHead, category);
				printf("%s\n", argv[2]);
				ctrl = 0;
				free(category);
				free(listHead);
				free(newStd);
				break;
			default:
				break;
			}
			if(ctrl == 1){
				option = displayOption();
			}
		}
	}	
}
