/*
 BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF 
THE WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN 
THIS FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE 
INSTRUCTOR OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE 
TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY. 
*/
#include "lab4.h"
/* insert a new student into linked list and add grades.
** @param *listHead
**		the start of student linked list
** @param *newStd
**		the new student node need to be inserted in
** @param *caregory_Names
**		catory name for student grade
*/
void insertNewStd(Node **listHead, char *category_Names){
	int stdID;
	int counter;
	int i;
	float finalCumGrade[4];
	float catCumRatio[4];
	Node *newStd;
	Node *traversePtr;
	catCumRatio[0] = 0.15;
	catCumRatio[1] = 0.3;
	catCumRatio[2] = 0.2;
	catCumRatio[3] = 0.35;

	newStd = malloc(sizeof(Node));
	/* get student name */
	printf("Enter the Student's Name: ");
	scanf(" %[^\n]", &newStd->Student.student_name);
	/* get student ID */
	printf("Enter the Student ID number: ");
	scanf(" %i", &stdID);
	/* when duplicate, keep asking new ID */
	while(ID_isduplicate(*listHead, stdID) != 0){
		printf("Student ID Number entered was a duplicate.\n");
		printf("Enter the student's ID Number: ");
		scanf(" %i", &stdID);
	}
	newStd->Student.student_ID = stdID;
	/* get quizzes score */
	printf("Enter first Quizzes score (use -1 if there is no score): ");
	scanf("%f", &newStd->Student.Cat1.score1);
	printf("Enter second Quizzes score (use -1 if there is no score): ");
	scanf("%f", &newStd->Student.Cat1.score2);
	printf("Enter third Quizzes score (use -1 if there is no score): ");
	scanf("%f", &newStd->Student.Cat1.score3);
	/* get Midterms score */
	printf("Enter first Midterm score (use -1 if there is no score): ");
	scanf("%f", &newStd->Student.Cat2.score1);
	printf("Enter second Midterm score (use -1 if there is no score): ");
	scanf("%f", &newStd->Student.Cat2.score2);
	printf("Enter third Midterm score (use -1 if there is no score): ");
	scanf("%f", &newStd->Student.Cat2.score3);
	/* get Homework score */
	printf("Enter first Homework score (use -1 if there is no score): ");
	scanf("%f", &newStd->Student.Cat3.score1);
	printf("Enter second Homework score (use -1 if there is no score): ");
	scanf("%f", &newStd->Student.Cat3.score2);
	printf("Enter third Homework score (use -1 if there is no score): ");
	scanf("%f", &newStd->Student.Cat3.score3);
	/* get Final score */
	printf("Enter first Final score (use -1 if there is no score): ");
	scanf("%f", &newStd->Student.Cat4.score1);
	printf("Enter second Final score (use -1 if there is no score): ");
	scanf("%f", &newStd->Student.Cat4.score2);
	printf("Enter third Final score (use -1 if there is no score): ");
	scanf("%f", &newStd->Student.Cat4.score3);
	/* calculate Cat1 cumulative scores */
	if((int)(newStd->Student.Cat1.score1) == -1){
		counter++;
	}
	if((int)(newStd->Student.Cat1.score2) == -1){
		counter++;
	}
	if((int)(newStd->Student.Cat1.score3) == -1){
		counter++;
	}
	switch (counter){
		case 1 :
			newStd->Student.Cat1.Cumulative = (newStd->Student.Cat1.score1 + newStd->Student.Cat1.score2 + newStd->Student.Cat1.score3 + 1)/2;
			finalCumGrade[0] = newStd->Student.Cat1.Cumulative;
			break;
		case 2 :
			newStd->Student.Cat1.Cumulative = newStd->Student.Cat1.score1 + newStd->Student.Cat1.score2 + newStd->Student.Cat1.score3 + 2;
			finalCumGrade[0] = newStd->Student.Cat1.Cumulative;
			break;
		case 3 :
			newStd->Student.Cat1.Cumulative = -1;
			finalCumGrade[0] = 100;
			break;
		default :
			newStd->Student.Cat1.Cumulative = (newStd->Student.Cat1.score1 + newStd->Student.Cat1.score2 + newStd->Student.Cat1.score3)/3;
			finalCumGrade[0] = newStd->Student.Cat1.Cumulative;
	}
	counter = 0;
	/* calculate Cat2 cumulative scores */
	if((int)(newStd->Student.Cat2.score1) == -1){
		counter++;
	}
	if((int)(newStd->Student.Cat2.score2) == -1){
		counter++;
	}
	if((int)(newStd->Student.Cat2.score3) == -1){
		counter++;
	}
	switch (counter){
		case 1 :
			newStd->Student.Cat2.Cumulative = (newStd->Student.Cat2.score1 + newStd->Student.Cat2.score2 + newStd->Student.Cat2.score3 + 1)/2;
			finalCumGrade[1] = newStd->Student.Cat2.Cumulative;
			break;
		case 2 :
			newStd->Student.Cat2.Cumulative = newStd->Student.Cat2.score1 + newStd->Student.Cat2.score2 + newStd->Student.Cat2.score3 + 2;
			finalCumGrade[1] = newStd->Student.Cat2.Cumulative;
			break;
		case 3 :
			newStd->Student.Cat2.Cumulative = -1;
			finalCumGrade[1] = 100;
			break;
		default :
			newStd->Student.Cat2.Cumulative = (newStd->Student.Cat2.score1 + newStd->Student.Cat2.score2 + newStd->Student.Cat2.score3)/3;
			finalCumGrade[1] = newStd->Student.Cat2.Cumulative;
	}
			counter = 0;
	/* calculate Cat3 cumulative scores */
	if((int)(newStd->Student.Cat3.score1) == -1){
		counter++;
	}
	if((int)(newStd->Student.Cat3.score2) == -1){
		counter++;
	}
	if((int)(newStd->Student.Cat3.score3) == -1){
		counter++;
	}
	switch (counter){
		case 1 :
			newStd->Student.Cat3.Cumulative = (newStd->Student.Cat3.score1 + newStd->Student.Cat3.score2 + newStd->Student.Cat3.score3 + 1)/2;
			finalCumGrade[2] = newStd->Student.Cat3.Cumulative;
			break;
		case 2 :
			newStd->Student.Cat3.Cumulative = newStd->Student.Cat3.score1 + newStd->Student.Cat3.score2 + newStd->Student.Cat3.score3 + 2;
			finalCumGrade[2] = newStd->Student.Cat3.Cumulative;
			break;
		case 3 :
			newStd->Student.Cat3.Cumulative = -1;
			finalCumGrade[2] = 100;
			break;
		default :
			newStd->Student.Cat3.Cumulative = (newStd->Student.Cat3.score1 + newStd->Student.Cat3.score2 + newStd->Student.Cat3.score3)/3;
			finalCumGrade[2] = newStd->Student.Cat3.Cumulative;
	}
	counter = 0;
	/* calculate Cat4 cumulative scores */
	if((int)(newStd->Student.Cat4.score1) == -1){
		counter++;
	}
	if((int)(newStd->Student.Cat4.score2) == -1){
		counter++;
	}
	if((int)(newStd->Student.Cat4.score3) == -1){
		counter++;
	}
	switch (counter){
		case 1 :
			newStd->Student.Cat4.Cumulative = (newStd->Student.Cat4.score1 + newStd->Student.Cat4.score2 + newStd->Student.Cat4.score3 + 1)/2;
			finalCumGrade[3] = newStd->Student.Cat4.Cumulative;
			break;
		case 2 :
			newStd->Student.Cat4.Cumulative = newStd->Student.Cat4.score1 + newStd->Student.Cat4.score2 + newStd->Student.Cat4.score3 + 2;
			finalCumGrade[3] = newStd->Student.Cat4.Cumulative;
			break;
		case 3 :
			newStd->Student.Cat4.Cumulative = -1;
			finalCumGrade[3] = 100;
			break;
		default :
			newStd->Student.Cat4.Cumulative = (newStd->Student.Cat4.score1 + newStd->Student.Cat4.score2 + newStd->Student.Cat4.score3)/3;
			finalCumGrade[3] = newStd->Student.Cat4.Cumulative;
	}
	counter = 0;
	/* calculate Current_Grade */
	for(i = 0; i < 4; i++){
		newStd->Student.Current_Grade += catCumRatio[i] * finalCumGrade[i];
	}
	insertNodeToList(listHead, newStd);
	/* print student info and grade */
	printHeader(category_Names);
	traversePtr = *listHead;
	while(traversePtr != NULL){
		printStudent(traversePtr);
		printf("%.2f\t", newStd->Student.Current_Grade);
		printf("n/a\n");
		traversePtr = traversePtr->next;
	}
	printf("\n");
}
