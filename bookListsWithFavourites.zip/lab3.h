/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF THE 
** WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN THIS 
** FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE INSTRUCTOR 
** OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE TENURES OF THE 
** OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.      
*/
char *alloc_title_array(char *input_array, int i, char input);
void populate_fav_book_list(int number, int fav_book_quantity, int *fav_book_num, char **title_ptr, int i);
void save_fav_book_list_to_file(FILE *file_ptr, char *file_name_ptr, int *fav_book, char **title_ptr, int total_book_quantity, int chosen_book_quantity, int i);
void free_pointers(int *fav_book_num, char *input_array, char **title_ptr);
void free_all_pointers(int *fav_book_num, char *input_array, char *file_name_ptr, char **title_ptr);