 /* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF THE
** WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN THIS
** FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE INSTRUCTOR
** OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE TENURES OF THE
** OHIO STATE UNIVERSITY'S ACADEMIC INTEGRITY POLICY.
*/
#include <stdio.h>
#include <stdlib.h>
/* Author: Zhiren Xu */	
main ()
{
  char text[201];		/* a 201-bit char array */
  char rawKey[5];		/* a 5-bit key w/ '\0' */
  unsigned char internalKey;	/* a 8-bit binary key that w/o '\0' */
  char c0;			/* a char with hex value of 0x00000000 */
  char c1;			/* a char with hex value of 0x00000001 */
  int k;			/* iterator for 10 hex value per row */
  int i;			/* iterator for initial input of text & key */

  #ifdef PROMPT
  printf ("enter cleartext: ");
  #endif
  i = 0;
  while (i < 200)
    {
      text[i] = (char) getchar ();	/*get user input */
      if (text[i] == '\n')
	{			/* when user hit enter, stop reading */
	  break;
	}
      i++;
    }

  #ifdef PROMPT
  i = 0;			/* reset iterator */
  printf ("Text entered is: ");	/* print out recived clear text */
  printf ("%s", text);
  
  k = 0;
  printf ("Hex encoding is: \n");
  while (text[i] != '\n')
    {				/* print out char in hex */
      printf ("%02x", text[i++]);
      printf (" ");
      k++;
      if (k == 10)
	{			/* when print 10 hex value, change line */
	  printf ("\n");
	  k = 0;
	} 
    }
  printf ("\n");
  #endif

  #ifdef PROMPT
  printf ("enter 4-bit key: ");
  #endif
  i = 0;
  while (i < 4)
    {
      rawKey[i] = (char) getchar ();
      i++;
    }
  	
  /* use bitwise to transfer 4 bit rawKey to 8 bit internalKey */
  internalKey = 0x00000000;	/* initialize, get rid of garbage in mem address */
  c0 = 0x00000000;
  c1 = 0x00000001;
  for (i = 0; i < 4; i++){
	if(rawKey[i] == '0'){
		internalKey = internalKey | c0;
	}else if(rawKey[i] == '1'){
		internalKey = internalKey | c1;
	}
	internalKey = internalKey << 1;
  }
  for (i = 0; i < 4; i++){
	if(rawKey[i] == '0'){
		internalKey = internalKey | c0;
	}else if(rawKey[i] == '1'){
		internalKey = internalKey | c1;
	}
	internalKey = internalKey << 1;
  }
  internalKey = internalKey >> 1;
  #ifdef PROMPT
  /* XOR clear text */
  printf ("hex ciphertext: \n");
  #endif
  i = 0;
  k = 0;
  while (text[i] != '\n')
    {
      printf ("%02x", text[i] ^ internalKey);
      printf (" ");
      k++;
      #ifdef PROMPT
      if (k == 10)
	{
	  printf ("\n");
	  k = 0;
	}
      #endif
      i++;
    }
  printf("\n");
}

